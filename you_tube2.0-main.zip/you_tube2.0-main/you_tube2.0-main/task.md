# Role

Act as a Senior Software Engineer with 10+ years of experience in Node.js, Express, MongoDB, system design, automated testing, and Docker.

I already have an existing video streaming platform with source code. This is an interview selection project.

**Your job is to extend the existing application, not create a new project or rewrite the application from scratch.**

Inspect the current implementation, understand its architecture, implement the requested features, integrate them with existing functionality, write end-to-end tests, and verify the results.

The objective is to finish the project and test it successfully, not just generate code or documentation.

# 1. Existing Technology Stack

The project already uses:

- Node.js with ES modules (`"type": "module"`).
- Express 5.1.0.
- MongoDB with Mongoose 8.16.0.
- JWT authentication using `jsonwebtoken`.
- Multer and `express-fileupload`.
- Static file serving through `/uploads`.
- `cors`, `body-parser`, and `dotenv`.
- Nodemon.
- MVC architecture with existing `routes/`, `controllers/`, and `Modals/` directories.

Preserve the existing technology stack and project structure.

Reuse existing routes, controllers, models, middleware, utilities, authentication, and frontend components wherever possible.

Do not introduce a new frontend framework or replace existing implementations unnecessarily.

# 2. Mandatory Workflow

## Step 1: Inspect the existing codebase

Before editing anything:

1. Inspect the project directory and existing source files.
2. Read `package.json` and the lockfile.
3. Understand the existing user, video, authentication, comment, like, history, and watch-later implementations.
4. Identify existing frontend components and API integrations.
5. Identify existing testing infrastructure.
6. Determine which parts of the requested features are already implemented.
7. Identify missing functionality and existing bugs relevant to these tasks.

Create a concise checklist of missing functionality.

**Do not recreate functionality that already exists. Extend or fix it instead.**

Do not stop after producing the checklist. Continue implementing the tasks.

## Step 2: Implement the six requested features

Implement each feature directly in the existing codebase.

Use the existing MVC structure and introduce a service layer only where useful.

Maintain backward compatibility with existing functionality.

Do not perform unrelated refactoring.

## Step 3: Test each feature

Write unit and integration tests where appropriate, plus end-to-end tests for complete user workflows.

Run the tests after implementing each feature.

Fix failures before proceeding to the next feature.

## Step 4: Configure Docker

Make the existing application runnable without requiring local Node.js, npm, or MongoDB installations.

Create or update Dockerfiles, Docker Compose configuration, `.dockerignore`, `.env.example`, and `.gitignore` as necessary.

## Step 5: Final verification

Start the application using Docker, run the available automated tests, fix regressions, and update the existing README.

Report the actual results. Never claim a test passed if it was not executed successfully.
---
#Step 6 : features to implement
---
1.Watch Party

Implement a watch party feature that allows users to invite friends to watch videos together in real time. Support video calls, chat, optional screen sharing, mute/unmute, camera on/off, leave call, and a participant list. Session recording is optional and can be stored locally or made available only to the host.

2.Controlled Video Downloads

Allow free users to download one video per day and premium users to download more videos according to their subscription plans. Add a Downloads section to the user profile. Track download count, download date, user plan, and video details. Apply restrictions to prevent unlimited downloads by free users.

3. Subscription Upgrade

Implement Free, Bronze, Silver, and Gold subscription plans. Free users should have limited access to premium videos or selected features. Paid plans should unlock additional benefits, including longer watch time, downloads, and ad-free viewing. Integrate Razorpay in test mode. After successful payment, update the user's plan in the database and send an invoice or confirmation email containing plan details and transaction information.

4. Custom Video Player

Implement a custom video player with play/pause, volume control, fullscreen mode, and forward/backward seeking by 10 seconds. Optionally support mobile gestures, such as double-tapping the right side to skip forward and the left side to rewind. Display video duration, current playback time, loading state, and a next-video option.

5. Personalized Theme and Login Security

Automatically apply the light theme when a user logs in between 10:00 AM and 12:00 PM IST. Apply the dark theme by default at all other times. Save the selected theme in the user's profile and allow manual changes. Require OTP verification through the registered email or mobile number when a user logs in from a new city, state, or device.

6. Multilingual Comments and Moderation

Allow users to post comments in different languages and provide an option to translate comments into their preferred language. Display the username and posting time for each comment. Make location display optional for privacy. Detect and block abusive words, spam, and comments containing repeated special characters. Support liking, disliking, and reporting comments. Flag reported comments for review rather than automatically deleting them after a fixed number of dislikes.

# 7. Docker: Run the Existing Project With One Command

I do not want to install Node.js, npm, MongoDB, or application dependencies locally.

Use Docker and Docker Compose for the complete development environment.

Do not replace the existing application just to accommodate Docker.

Create or update:

- `Dockerfile`.
- `docker-compose.yml`.
- `.dockerignore`.
- `.env.example`.
- `.gitignore`.

Add a frontend container if the existing repository has a separate frontend.

Use a compatible, pinned Node.js image and MongoDB image.

Run Nodemon inside the backend container.

Use bind mounts for source-code hot reload and a Docker-managed volume for `node_modules`.

Use named volumes for MongoDB data and uploaded files.

Configure health checks and database readiness.

Do not expose MongoDB unnecessarily.

Read credentials from environment variables.

The following command must start the complete local environment:

```bash
docker compose up --build
```

After the initial build, subsequent runs should support:

```bash
docker compose up
```

The application must not require manual installation of Node.js or MongoDB.

Do not introduce Kubernetes, microservices, or other unnecessary infrastructure.

### 8.Docker-based testing

All automated tests must be runnable inside Docker.

Provide working commands for unit, integration, and end-to-end tests.

Use an isolated test database.

Ensure failed tests return a nonzero exit status.

Do not allow tests to modify development data.

If Docker is unavailable in the current execution environment, prepare the configuration and report that runtime verification remains outstanding.

---

# 9. End-to-End Testing

Write tests that exercise the existing application and all six enhancements.

Use the existing test framework if one is already configured. Otherwise, choose compatible tools such as Jest or Vitest, Supertest, and Playwright.

Test complete workflows where practical.

Examples:

### Subscription workflow

A user selects a plan, completes a mocked Razorpay test payment, passes server-side verification, receives an active subscription, and gains the correct entitlements.

### Download workflow

A free user downloads a video, attempts another download on the same IST calendar day, receives the appropriate restriction, and sees the download in their profile.

### Watch party workflow

A host creates a party, another authenticated user joins, participants synchronize playback, exchange messages, and leave the party.

### Authentication workflow

A user logs in, receives the correct default theme, completes additional OTP verification when required, and retains their manual theme preference.

### Comment workflow

A user posts a comment, translates it, reacts to it, reports inappropriate content, and an administrator reviews the report.

### Video player workflow

A user opens a video, uses playback controls, seeks forward and backward, and navigates to the next video.

Include failure paths, authorization checks, and concurrency cases.

Mock external Razorpay, email, SMS, and translation services.

Do not substitute unit tests for end-to-end tests when a complete workflow can reasonably be tested.

---

# 10. Update README.md

Update the existing README rather than replacing useful project documentation.

Include:

- Existing project overview.
- Features implemented.
- Technology stack.
- Important architectural decisions.
- Installation and Docker prerequisites.
- Environment configuration.
- Single-command startup.
- Application URLs.
- API endpoints.
- Razorpay test setup.
- External provider configuration.
- Running automated tests.
- Viewing Docker logs.
- Stopping containers.
- Persistent database and upload storage.
- Known limitations.

Ensure the commands match the actual Docker Compose services and `package.json` scripts.

Do not document unimplemented features as completed.

---

# 11. Final Execution and Verification

After implementation:

1. Inspect the modified files.
2. Check imports and exports.
3. Verify route registration.
4. Verify database models and indexes.
5. Run tests for each feature.
6. Run the complete test suite.
7. Start the application using Docker.
8. Test application startup and database connectivity.
9. Run the available end-to-end tests.
10. Fix regressions and failed tests.
11. Update the README.
12. Review the final changes for unnecessary modifications.

Do not claim tests passed unless they actually passed.

If an external credential or service is missing, test everything possible locally and clearly identify the remaining limitation.

At the end, report:

- Features implemented.
- Existing files modified.
- New files created.
- Tests executed.
- Actual test results.
- Docker startup command.
- Any remaining blockers.

# Final Instruction

**This is an existing codebase. Extend it; do not rebuild it.**

