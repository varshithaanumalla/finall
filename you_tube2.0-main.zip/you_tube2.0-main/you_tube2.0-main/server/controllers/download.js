import download from "../Modals/download.js";
import video from "../Modals/video.js";
import user from "../Modals/Auth.js";
import path from "path";
import fs from "fs";

// Download limits per plan (videos per IST calendar day)
const DOWNLOAD_LIMITS = {
  free: 1,
  bronze: 10,
  silver: 25,
  gold: 50,
};

/**
 * Get IST date range for the current day
 * IST is UTC+5:30
 */
function getISTDayRange() {
  const now = new Date();
  // Convert to IST by adding 5h30m
  const istOffset = 5.5 * 60 * 60 * 1000;
  const istTime = new Date(now.getTime() + istOffset);
  const istDayStart = new Date(
    Date.UTC(istTime.getUTCFullYear(), istTime.getUTCMonth(), istTime.getUTCDate(), 0, 0, 0)
  );
  const istDayEnd = new Date(
    Date.UTC(istTime.getUTCFullYear(), istTime.getUTCMonth(), istTime.getUTCDate(), 23, 59, 59)
  );
  // Subtract the IST offset back to get the correct UTC range
  return { start: new Date(istDayStart.getTime() - istOffset), end: new Date(istDayEnd.getTime() - istOffset) };
}

/**
 * Check if user can download a video based on their plan
 */
export const checkDownloadLimit = async (req, res) => {
  try {
    const userId = req.user.userId;
    const { videoId } = req.params;

    const userDoc = await user.findById(userId);
    if (!userDoc) {
      return res.status(404).json({ message: "User not found" });
    }

    const plan = userDoc.subscriptionPlan || "free";
    const limit = DOWNLOAD_LIMITS[plan];

    const { start, end } = getISTDayRange();

    const todayCount = await download.countDocuments({
      userId,
      downloadDate: { $gte: start, $lte: end },
    });

    const canDownload = todayCount < limit;

    return res.status(200).json({
      canDownload,
      todayCount,
      limit,
      plan,
      remaining: Math.max(0, limit - todayCount),
    });
  } catch (error) {
    console.error("Check download limit error:", error);
    return res.status(500).json({ message: "Something went wrong" });
  }
};

/**
 * Download a video (records the download and streams the file)
 */
export const downloadVideo = async (req, res) => {
  try {
    const userId = req.user.userId;
    const { videoId } = req.params;

    const userDoc = await user.findById(userId);
    if (!userDoc) {
      return res.status(404).json({ message: "User not found" });
    }

    const videoDoc = await video.findById(videoId);
    if (!videoDoc) {
      return res.status(404).json({ message: "Video not found" });
    }

    const plan = userDoc.subscriptionPlan || "free";
    const limit = DOWNLOAD_LIMITS[plan];

    // Check daily limit based on IST calendar day
    const { start, end } = getISTDayRange();
    const todayCount = await download.countDocuments({
      userId,
      downloadDate: { $gte: start, $lte: end },
    });

    if (todayCount >= limit) {
      return res.status(403).json({
        message: `Daily download limit reached. Your ${plan} plan allows ${limit} download(s) per day. Upgrade your subscription to download more.`,
        limit,
        todayCount,
      });
    }

    // Record the download
    const downloadRecord = await download.create({
      userId,
      videoId,
      videotitle: videoDoc.videotitle,
      videochanel: videoDoc.videochanel,
      filepath: videoDoc.filepath,
      filesize: videoDoc.filesize,
      userPlan: plan,
    });

    // Update user download stats
    userDoc.downloadCount = (userDoc.downloadCount || 0) + 1;
    userDoc.lastDownloadDate = new Date();
    await userDoc.save();

    // Stream the video file
    const filePath = path.resolve(videoDoc.filepath);
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ message: "Video file not found on server" });
    }

    const stat = fs.statSync(filePath);
    const fileSize = stat.size;
    const range = req.headers.range;

    if (range) {
      const parts = range.replace(/bytes=/, "").split("-");
      const startByte = parseInt(parts[0], 10);
      const endByte = parts[1] ? parseInt(parts[1], 10) : fileSize - 1;
      const chunksize = endByte - startByte + 1;
      const stream = fs.createReadStream(filePath, { start: startByte, end: endByte });
      const head = {
        "Content-Range": `bytes ${startByte}-${endByte}/${fileSize}`,
        "Accept-Ranges": "bytes",
        "Content-Length": chunksize,
        "Content-Type": "video/mp4",
        "Content-Disposition": `attachment; filename="${videoDoc.videotitle || "video"}.mp4"`,
      };
      res.writeHead(206, head);
      stream.pipe(res);
    } else {
      const head = {
        "Content-Length": fileSize,
        "Content-Type": "video/mp4",
        "Content-Disposition": `attachment; filename="${videoDoc.videotitle || "video"}.mp4"`,
      };
      res.writeHead(200, head);
      fs.createReadStream(filePath).pipe(res);
    }
  } catch (error) {
    console.error("Download video error:", error);
    return res.status(500).json({ message: "Something went wrong" });
  }
};

/**
 * Get all downloads for a user (Downloads section in profile)
 */
export const getUserDownloads = async (req, res) => {
  try {
    const userId = req.user.userId;
    const downloads = await download
      .find({ userId })
      .sort({ downloadDate: -1 });

    return res.status(200).json({ downloads });
  } catch (error) {
    console.error("Get downloads error:", error);
    return res.status(500).json({ message: "Something went wrong" });
  }
};

/**
 * Get download statistics for a user
 */
export const getDownloadStats = async (req, res) => {
  try {
    const userId = req.user.userId;

    const userDoc = await user.findById(userId);
    if (!userDoc) {
      return res.status(404).json({ message: "User not found" });
    }

    const plan = userDoc.subscriptionPlan || "free";
    const limit = DOWNLOAD_LIMITS[plan];

    const { start, end } = getISTDayRange();
    const todayCount = await download.countDocuments({
      userId,
      downloadDate: { $gte: start, $lte: end },
    });

    const totalCount = await download.countDocuments({ userId });

    return res.status(200).json({
      plan,
      dailyLimit: limit,
      todayCount,
      totalCount,
      remaining: Math.max(0, limit - todayCount),
    });
  } catch (error) {
    console.error("Get download stats error:", error);
    return res.status(500).json({ message: "Something went wrong" });
  }
};

export { DOWNLOAD_LIMITS };
