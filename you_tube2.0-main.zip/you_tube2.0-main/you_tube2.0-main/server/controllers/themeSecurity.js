import user from "../Modals/Auth.js";
import jwt from "jsonwebtoken";
import crypto from "crypto";
import nodemailer from "nodemailer";
import { sendEmail } from "../utils/email.js";

/**
 * Determine the default theme based on IST time.
 * Light theme: 10:00 AM - 12:00 PM IST
 * Dark theme: all other times
 */
function getDefaultTheme() {
  // Optional override for testing/demo: set THEME_TEST_HOUR to a number 0-23
  // to simulate a specific IST hour (e.g. 10 => light). Remove/unset for real
  // clock behaviour.
  let istHour;
  if (process.env.THEME_TEST_HOUR !== undefined && process.env.THEME_TEST_HOUR !== "") {
    istHour = parseInt(process.env.THEME_TEST_HOUR, 10);
  } else {
    const now = new Date();
    const istOffset = 5.5 * 60 * 60 * 1000; // UTC+5:30
    const istTime = new Date(now.getTime() + istOffset);
    istHour = istTime.getUTCHours();
  }

  if (istHour >= 10 && istHour < 12) {
    return "light";
  }
  return "dark";
}

/**
 * Generate a 6-digit OTP
 */
function generateOTP() {
  return crypto.randomInt(100000, 999999).toString();
}

/**
 * Send OTP via email.
 * Returns true only when a real email provider (EMAIL_USER/EMAIL_PASS) is
 * configured and the message was accepted. In that case the OTP is NOT
 * exposed to the client. Otherwise returns false so the caller can surface
 * the OTP for local/dev testing.
 */
async function sendOTP(email, otp) {
  const subject = "YourTube - Login Verification OTP";
  const html = `
    <div style="font-family:Arial,sans-serif;max-width:480px;margin:auto;border:1px solid #eee;border-radius:8px;overflow:hidden">
      <div style="background:#ef4444;color:#fff;padding:16px 20px;font-size:18px;font-weight:bold">YourTube</div>
      <div style="padding:20px">
        <h2 style="margin:0 0 8px">Login Verification Required</h2>
        <p style="color:#444">A login attempt was detected from a new location or device.</p>
        <p style="color:#444">Your one-time password (OTP) is:</p>
        <div style="font-size:32px;font-weight:bold;letter-spacing:8px;background:#f3f4f6;padding:16px;text-align:center;border-radius:6px;margin:12px 0">${otp}</div>
        <p style="color:#888;font-size:13px">This code expires in 10 minutes. If this wasn't you, you can ignore this email.</p>
      </div>
    </div>
  `;
  const result = await sendEmail({ to: email, subject, html });
  return {
    realEmail: result.delivered,
    previewUrl: result.previewUrl,
    from: process.env.EMAIL_FROM_NAME || "YourTube Security",
    subject,
    html,
  };
}

/**
 * Login with theme detection and OTP verification for new locations/devices
 */
export const loginWithSecurity = async (req, res) => {
  const { email, name, image } = req.body;
  const { city, state, device } = req.body;

  try {
    let existingUser = await user.findOne({ email });

    if (!existingUser) {
      // New user - create account
      const defaultTheme = getDefaultTheme();
      existingUser = await user.create({
        email,
        name,
        image,
        theme: defaultTheme,
        knownDevices: device ? [device] : [],
        knownLocations: city ? [`${city}, ${state || ""}`] : [],
      });

      const token = jwt.sign(
        { userId: existingUser._id, email: existingUser.email, name: existingUser.name, image: existingUser.image },
        process.env.JWT_SECRET || "yourtube_secret_key",
        { expiresIn: "7d" }
      );

      return res.status(201).json({
        result: existingUser,
        token,
        requiresOTP: false,
        theme: existingUser.theme,
      });
    }

    // Check if login is from a new location or device
    const location = city ? `${city}, ${state || ""}` : null;
    const isNewLocation = location && !existingUser.knownLocations.includes(location);
    const isNewDevice = device && !existingUser.knownDevices.includes(device);

    // OTP verification is gated behind OTP_ENABLED. It is disabled by default
    // because it requires a configured email/SMS provider to deliver codes.
    // Enable it (OTP_ENABLED=true) once EMAIL_USER/EMAIL_PASS are set.
    const otpEnabled = process.env.OTP_ENABLED === "true";
    const requiresOTP = otpEnabled && (isNewLocation || isNewDevice);

    if (requiresOTP) {
      // Reuse an existing, still-valid OTP if one is already pending. This
      // makes the flow resilient to duplicate login-secure calls (which would
      // otherwise regenerate the code and invalidate the one already emailed).
      let otp;
      const hasValidOtp =
        existingUser.otp && existingUser.otpExpiry && new Date() < existingUser.otpExpiry;
      if (hasValidOtp) {
        otp = existingUser.otp;
      } else {
        otp = generateOTP();
        existingUser.otp = otp;
        existingUser.otpExpiry = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes
      }
      existingUser.pendingLoginData = { city, state, device };
      await existingUser.save();

      // Send OTP via email. Returns the rendered email so the frontend can
      // display it in an in-app "inbox" (zero external setup needed).
      const sent = await sendOTP(existingUser.email, otp);

      return res.status(200).json({
        requiresOTP: true,
        email: existingUser.email,
        message: sent.realEmail
          ? "OTP sent to your registered email. Please check your inbox."
          : "A verification email was sent. Open it below to get your code.",
        previewUrl: sent.previewUrl || undefined,
        // In-app inbox content (shown when real inbox delivery isn't configured).
        emailPreview: sent.realEmail
          ? undefined
          : { from: sent.from, subject: sent.subject, html: sent.html },
      });
    }

    // OTP disabled (or known device/location): record any new device/location
    // so the profile stays accurate, then log the user in directly.
    if (isNewLocation && location) {
      existingUser.knownLocations.push(location);
    }
    if (isNewDevice && device) {
      existingUser.knownDevices.push(device);
    }
    if (isNewLocation || isNewDevice) {
      await existingUser.save();
    }

    // Known location/device - proceed with normal login
    const token = jwt.sign(
      { userId: existingUser._id, email: existingUser.email, name: existingUser.name, image: existingUser.image },
      process.env.JWT_SECRET || "yourtube_secret_key",
      { expiresIn: "7d" }
    );

    return res.status(200).json({
      result: existingUser,
      token,
      requiresOTP: false,
      theme: existingUser.theme,
    });
  } catch (error) {
    console.error("Login security error:", error);
    return res.status(500).json({ message: "Something went wrong" });
  }
};

/**
 * Verify OTP and complete login
 */
export const verifyOTP = async (req, res) => {
  const { email, otp } = req.body;

  try {
    const userDoc = await user.findOne({ email });

    if (!userDoc) {
      return res.status(404).json({ message: "User not found" });
    }

    if (!userDoc.otp || !userDoc.otpExpiry) {
      return res.status(400).json({ message: "No OTP was generated" });
    }

    // Check if OTP is expired
    if (new Date() > userDoc.otpExpiry) {
      return res.status(400).json({ message: "OTP has expired. Please login again." });
    }

    if (userDoc.otp !== otp) {
      return res.status(400).json({ message: "Invalid OTP" });
    }

    // OTP is valid - complete login
    const pendingData = userDoc.pendingLoginData || {};
    if (pendingData.city) {
      userDoc.knownLocations.push(`${pendingData.city}, ${pendingData.state || ""}`);
    }
    if (pendingData.device) {
      userDoc.knownDevices.push(pendingData.device);
    }

    // Clear OTP data
    userDoc.otp = null;
    userDoc.otpExpiry = null;
    userDoc.pendingLoginData = null;
    await userDoc.save();

    const token = jwt.sign(
      { userId: userDoc._id, email: userDoc.email, name: userDoc.name, image: userDoc.image },
      process.env.JWT_SECRET || "yourtube_secret_key",
      { expiresIn: "7d" }
    );

    return res.status(200).json({
      result: userDoc,
      token,
      requiresOTP: false,
      theme: userDoc.theme,
      message: "Login successful",
    });
  } catch (error) {
    console.error("Verify OTP error:", error);
    return res.status(500).json({ message: "Something went wrong" });
  }
};

/**
 * Update user theme preference (manual override)
 */
export const updateTheme = async (req, res) => {
  try {
    const userId = req.user.userId;
    const { theme } = req.body;

    if (!["light", "dark", "auto"].includes(theme)) {
      return res.status(400).json({ message: "Invalid theme. Must be 'light', 'dark', or 'auto'" });
    }

    const userDoc = await user.findByIdAndUpdate(userId, { theme }, { new: true });

    if (!userDoc) {
      return res.status(404).json({ message: "User not found" });
    }

    return res.status(200).json({ theme: userDoc.theme });
  } catch (error) {
    console.error("Update theme error:", error);
    return res.status(500).json({ message: "Something went wrong" });
  }
};

/**
 * Get current theme (resolves "auto" to actual based on IST time)
 */
export const getTheme = async (req, res) => {
  try {
    const userId = req.user.userId;
    const userDoc = await user.findById(userId);

    if (!userDoc) {
      return res.status(404).json({ message: "User not found" });
    }

    let effectiveTheme = userDoc.theme;
    if (effectiveTheme === "auto") {
      effectiveTheme = getDefaultTheme();
    }

    return res.status(200).json({
      theme: userDoc.theme,
      effectiveTheme,
    });
  } catch (error) {
    console.error("Get theme error:", error);
    return res.status(500).json({ message: "Something went wrong" });
  }
};

export { getDefaultTheme };
