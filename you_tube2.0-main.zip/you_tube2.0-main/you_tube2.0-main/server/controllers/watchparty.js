import watchparty from "../Modals/watchparty.js";
import video from "../Modals/video.js";

/**
 * Create a new watch party
 */
export const createParty = async (req, res) => {
  try {
    const { videoId } = req.body;
    const userId = req.user.userId;
    const userName = req.user.name || "Host";
    const userImage = req.user.image || "";

    const videoDoc = await video.findById(videoId);
    if (!videoDoc) {
      return res.status(404).json({ message: "Video not found" });
    }

    // Generate unique room ID
    const roomId = `party_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

    const party = await watchparty.create({
      hostId: userId,
      videoId,
      roomId,
      participants: [
        {
          userId,
          name: userName,
          image: userImage,
          muted: false,
          cameraOff: false,
        },
      ],
    });

    return res.status(201).json({ party });
  } catch (error) {
    console.error("Create party error:", error);
    return res.status(500).json({ message: "Something went wrong" });
  }
};

/**
 * Join an existing watch party by room ID
 */
export const joinParty = async (req, res) => {
  try {
    const { roomId } = req.params;
    const userId = req.user.userId;
    const userName = req.user.name || "Participant";
    const userImage = req.user.image || "";

    const party = await watchparty.findOne({ roomId, isActive: true });
    if (!party) {
      return res.status(404).json({ message: "Watch party not found or ended" });
    }

    // Check if already a participant
    const existing = party.participants.find(
      (p) => p.userId.toString() === userId
    );
    if (!existing) {
      party.participants.push({
        userId,
        name: userName,
        image: userImage,
        muted: false,
        cameraOff: false,
      });
      await party.save();
    }

    return res.status(200).json({ party });
  } catch (error) {
    console.error("Join party error:", error);
    return res.status(500).json({ message: "Something went wrong" });
  }
};

/**
 * Leave a watch party
 */
export const leaveParty = async (req, res) => {
  try {
    const { roomId } = req.params;
    const userId = req.user.userId;

    const party = await watchparty.findOne({ roomId, isActive: true });
    if (!party) {
      return res.status(404).json({ message: "Watch party not found" });
    }

    party.participants = party.participants.filter(
      (p) => p.userId.toString() !== userId
    );

    // If host leaves or no participants, end the party
    if (party.hostId.toString() === userId || party.participants.length === 0) {
      party.isActive = false;
    }

    await party.save();
    return res.status(200).json({ message: "Left party successfully" });
  } catch (error) {
    console.error("Leave party error:", error);
    return res.status(500).json({ message: "Something went wrong" });
  }
};

/**
 * Get party details
 */
export const getParty = async (req, res) => {
  try {
    const { roomId } = req.params;
    const party = await watchparty.findOne({ roomId, isActive: true });
    if (!party) {
      return res.status(404).json({ message: "Watch party not found" });
    }
    return res.status(200).json({ party });
  } catch (error) {
    console.error("Get party error:", error);
    return res.status(500).json({ message: "Something went wrong" });
  }
};

/**
 * Add a chat message to a party
 */
export const addMessage = async (req, res) => {
  try {
    const { roomId } = req.params;
    const { text } = req.body;
    const userId = req.user.userId;
    const userName = req.user.name || "User";

    const party = await watchparty.findOne({ roomId, isActive: true });
    if (!party) {
      return res.status(404).json({ message: "Watch party not found" });
    }

    party.messages.push({ userId, name: userName, text });
    await party.save();

    return res.status(200).json({ message: "Message added" });
  } catch (error) {
    console.error("Add message error:", error);
    return res.status(500).json({ message: "Something went wrong" });
  }
};

/**
 * Get all messages for a party
 */
export const getMessages = async (req, res) => {
  try {
    const { roomId } = req.params;
    const party = await watchparty.findOne({ roomId, isActive: true });
    if (!party) {
      return res.status(404).json({ message: "Watch party not found" });
    }
    return res.status(200).json({ messages: party.messages });
  } catch (error) {
    console.error("Get messages error:", error);
    return res.status(500).json({ message: "Something went wrong" });
  }
};

/**
 * Update participant mute/camera status
 */
export const updateParticipantStatus = async (req, res) => {
  try {
    const { roomId } = req.params;
    const { muted, cameraOff } = req.body;
    const userId = req.user.userId;

    const party = await watchparty.findOne({ roomId, isActive: true });
    if (!party) {
      return res.status(404).json({ message: "Watch party not found" });
    }

    const participant = party.participants.find(
      (p) => p.userId.toString() === userId
    );
    if (!participant) {
      return res.status(404).json({ message: "Participant not found" });
    }

    if (muted !== undefined) participant.muted = muted;
    if (cameraOff !== undefined) participant.cameraOff = cameraOff;
    await party.save();

    return res.status(200).json({ participant });
  } catch (error) {
    console.error("Update participant error:", error);
    return res.status(500).json({ message: "Something went wrong" });
  }
};

/**
 * Get all active parties for a user (host or participant)
 */
export const getUserParties = async (req, res) => {
  try {
    const userId = req.user.userId;
    const parties = await watchparty
      .find({
        isActive: true,
        "participants.userId": userId,
      })
      .populate("videoId", "videotitle filepath");
    return res.status(200).json({ parties });
  } catch (error) {
    console.error("Get user parties error:", error);
    return res.status(500).json({ message: "Something went wrong" });
  }
};
