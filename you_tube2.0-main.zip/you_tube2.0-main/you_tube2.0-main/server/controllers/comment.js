import comment from "../Modals/comment.js";
import mongoose from "mongoose";

// List of abusive words to detect (extensible)
const ABUSIVE_WORDS = [
  "spam",
  "scam",
  "fraud",
  "hate",
  "stupid",
  "idiot",
  "moron",
  "dumb",
  "trash",
  "garbage",
  "useless",
  "worthless",
  "pathetic",
  "terrible",
  "awful",
  "horrible",
  "disgusting",
  "shut up",
  "shutup",
];

// Repeated special characters pattern (e.g., "!!!!!!", "......", "@@@@@")
const REPEATED_SPECIAL_CHARS = /([!@#$%^&*()_+=\[\]{}|;:'",.<>?\/\\~`-])\1{4,}/;

// All-caps shouting detection (more than 70% caps)
const EXCESSIVE_CAPS = /^(?=.*[A-Z])[A-Z\s]{10,}$/;

/**
 * Check if comment text contains abusive words, spam, or repeated special characters
 */
export function detectAbuse(text) {
  if (!text) return { isAbusive: false, reason: null };

  const lowerText = text.toLowerCase();

  // Check for abusive words
  for (const word of ABUSIVE_WORDS) {
    if (lowerText.includes(word)) {
      return { isAbusive: true, reason: `Contains abusive word: ${word}` };
    }
  }

  // Check for repeated special characters (spam)
  if (REPEATED_SPECIAL_CHARS.test(text)) {
    return { isAbusive: true, reason: "Contains repeated special characters" };
  }

  // Check for excessive caps (shouting)
  if (EXCESSIVE_CAPS.test(text)) {
    return { isAbusive: true, reason: "Excessive capital letters detected" };
  }

  // Check for very long repeated text (spam pattern)
  const repeatedPattern = /(.{10,})\1{3,}/;
  if (repeatedPattern.test(text)) {
    return { isAbusive: true, reason: "Repeated text pattern detected (spam)" };
  }

  return { isAbusive: false, reason: null };
}

/**
 * Simple translation using a dictionary-based approach (no external API needed)
 * Supports: English (en), Hindi (hi), Spanish (es), French (fr), German (de)
 */
const translationDictionary = {
  // Common words mapped across languages
  "good": { hi: "अच्छा", es: "bueno", fr: "bon", de: "gut" },
  "great": { hi: "महान", es: "genial", fr: "grand", de: "großartig" },
  "video": { hi: "वीडियो", es: "vídeo", fr: "vidéo", de: "Video" },
  "awesome": { hi: "शानदार", es: "increíble", fr: "génial", de: "großartig" },
  "love": { hi: "प्रेम", es: "amor", fr: "amour", de: "Liebe" },
  "like": { hi: "पसंद", es: "como", fr: "comme", de: "wie" },
  "thanks": { hi: "धन्यवाद", es: "gracias", fr: "merci", de: "Danke" },
  "hello": { hi: "नमस्ते", es: "hola", fr: "bonjour", de: "Hallo" },
  "amazing": { hi: "अद्भुत", es: "asombroso", fr: "étonnant", de: "erstaunlich" },
  "nice": { hi: "अच्छा", es: "agradable", fr: "agréable", de: "schön" },
  "beautiful": { hi: "सुंदर", es: "hermoso", fr: "beau", de: "schön" },
  "watching": { hi: "देख रहा", es: "viendo", fr: "regarder", de: "ansehen" },
  "enjoyed": { hi: "आनंद लिया", es: "disfrutado", fr: "apprécié", de: "genossen" },
  "sharing": { hi: "साझा करना", es: "compartir", fr: "partage", de: "Teilen" },
  "content": { hi: "सामग्री", es: "contenido", fr: "contenu", de: "Inhalt" },
  "really": { hi: "वास्तव में", es: "realmente", fr: "vraiment", de: "wirklich" },
  "thank": { hi: "धन्यवाद", es: "gracias", fr: "merci", de: "Danke" },
  "you": { hi: "आप", es: "tú", fr: "vous", de: "Sie" },
  "this": { hi: "यह", es: "esto", fr: "ce", de: "dies" },
  "is": { hi: "है", es: "es", fr: "est", de: "ist" },
  "the": { hi: "वह", es: "el", fr: "le", de: "der" },
  "and": { hi: "और", es: "y", fr: "et", de: "und" },
  "for": { hi: "के लिए", es: "para", fr: "pour", de: "für" },
  "very": { hi: "बहुत", es: "muy", fr: "très", de: "sehr" },
};

/**
 * Translate text using the dictionary (word-by-word)
 * Falls back to original text for unknown words
 */
export function translateText(text, targetLang) {
  if (!text || targetLang === "en") return text;

  const words = text.split(/\s+/);
  const translated = words.map((word) => {
    const cleanWord = word.toLowerCase().replace(/[.,!?;:]/g, "");
    const translation = translationDictionary[cleanWord];
    if (translation && translation[targetLang]) {
      // Preserve capitalization of first letter
      if (word[0] === word[0].toUpperCase()) {
        return translation[targetLang].charAt(0).toUpperCase() + translation[targetLang].slice(1);
      }
      return translation[targetLang];
    }
    return word;
  });

  return translated.join(" ");
}

/**
 * Translate text using a real, keyless translation API (Google's public
 * endpoint). Falls back to the local dictionary if the API is unavailable.
 */
export async function translateViaApi(text, targetLang) {
  if (!text || targetLang === "en") return text;
  try {
    const url =
      "https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=" +
      encodeURIComponent(targetLang) +
      "&dt=t&q=" +
      encodeURIComponent(text);
    const res = await fetch(url, {
      headers: { "User-Agent": "Mozilla/5.0" },
    });
    if (!res.ok) throw new Error("translate api " + res.status);
    const data = await res.json();
    // Response shape: [[[ "translated chunk", "orig", ... ], ...], ...]
    const translated = (data[0] || [])
      .map((seg) => (seg && seg[0]) || "")
      .join("");
    return translated || translateText(text, targetLang);
  } catch (err) {
    console.error("translateViaApi failed, using dictionary:", err.message);
    return translateText(text, targetLang);
  }
}

/**
 * Detect language of text (simple heuristic)
 */
function detectLanguage(text) {
  // Hindi: Devanagari script
  if (/[\u0900-\u097F]/.test(text)) return "hi";
  // French: accented chars
  if (/[àâäçéèêëîïôûùüÿœ]/i.test(text)) return "fr";
  // Spanish: ñ, accented
  if (/[ñáéíóúü]/i.test(text)) return "es";
  // German: umlauts, ß
  if (/[äöüß]/i.test(text)) return "de";
  // Default to English
  return "en";
}

/**
 * Post a comment (with language detection and abuse filtering)
 */
export const postcomment = async (req, res) => {
  const commentdata = req.body;

  // Detect language
  if (!commentdata.language) {
    commentdata.language = detectLanguage(commentdata.commentbody);
  }

  // Check for abuse
  const abuseCheck = detectAbuse(commentdata.commentbody);
  if (abuseCheck.isAbusive) {
    commentdata.isFlagged = true;
    commentdata.isBlocked = true;
  }

  try {
    const newComment = new comment(commentdata);
    await newComment.save();

    if (abuseCheck.isAbusive) {
      return res.status(201).json({
        comment: true,
        message: "Your comment was flagged for review due to: " + abuseCheck.reason,
        flagged: true,
      });
    }

    return res.status(200).json({ comment: true });
  } catch (error) {
    console.error("Post comment error:", error);
    return res.status(500).json({ message: "Something went wrong" });
  }
};

/**
 * Get all comments for a video (excludes blocked comments)
 */
export const getallcomment = async (req, res) => {
  const { videoid } = req.params;
  try {
    const comments = await comment
      .find({ videoid: videoid, isBlocked: false })
      .sort({ commentedon: -1 });
    return res.status(200).json(comments);
  } catch (error) {
    console.error("Get comments error:", error);
    return res.status(500).json({ message: "Something went wrong" });
  }
};

/**
 * Translate a comment to the requested language
 */
export const translateComment = async (req, res) => {
  const { id } = req.params;
  const { targetLang } = req.body;

  if (!targetLang) {
    return res.status(400).json({ message: "Target language is required" });
  }

  try {
    const commentDoc = await comment.findById(id);
    if (!commentDoc) {
      return res.status(404).json({ message: "Comment not found" });
    }

    const translated = await translateViaApi(commentDoc.commentbody, targetLang);

    return res.status(200).json({
      original: commentDoc.commentbody,
      translated,
      sourceLang: commentDoc.language || "en",
      targetLang,
    });
  } catch (error) {
    console.error("Translate comment error:", error);
    return res.status(500).json({ message: "Something went wrong" });
  }
};

/**
 * Like a comment
 */
export const likeComment = async (req, res) => {
  const { id } = req.params;
  const { userId } = req.body;

  try {
    const commentDoc = await comment.findById(id);
    if (!commentDoc) {
      return res.status(404).json({ message: "Comment not found" });
    }

    // Remove from dislikes if present
    commentDoc.dislikes = commentDoc.dislikes.filter(
      (d) => d.toString() !== userId
    );

    // Toggle like
    if (commentDoc.likes.find((l) => l.toString() === userId)) {
      commentDoc.likes = commentDoc.likes.filter((l) => l.toString() !== userId);
    } else {
      commentDoc.likes.push(userId);
    }

    await commentDoc.save();

    return res.status(200).json({
      liked: commentDoc.likes.includes(userId),
      likeCount: commentDoc.likes.length,
      dislikeCount: commentDoc.dislikes.length,
    });
  } catch (error) {
    console.error("Like comment error:", error);
    return res.status(500).json({ message: "Something went wrong" });
  }
};

/**
 * Dislike a comment
 */
export const dislikeComment = async (req, res) => {
  const { id } = req.params;
  const { userId } = req.body;

  try {
    const commentDoc = await comment.findById(id);
    if (!commentDoc) {
      return res.status(404).json({ message: "Comment not found" });
    }

    // Remove from likes if present
    commentDoc.likes = commentDoc.likes.filter(
      (l) => l.toString() !== userId
    );

    // Toggle dislike
    if (commentDoc.dislikes.find((d) => d.toString() === userId)) {
      commentDoc.dislikes = commentDoc.dislikes.filter((d) => d.toString() !== userId);
    } else {
      commentDoc.dislikes.push(userId);
    }

    await commentDoc.save();

    return res.status(200).json({
      disliked: commentDoc.dislikes.includes(userId),
      likeCount: commentDoc.likes.length,
      dislikeCount: commentDoc.dislikes.length,
    });
  } catch (error) {
    console.error("Dislike comment error:", error);
    return res.status(500).json({ message: "Something went wrong" });
  }
};

/**
 * Report a comment (flags for review, does NOT auto-delete)
 */
export const reportComment = async (req, res) => {
  const { id } = req.params;
  const { userId, reason } = req.body;

  try {
    const commentDoc = await comment.findById(id);
    if (!commentDoc) {
      return res.status(404).json({ message: "Comment not found" });
    }

    // Check if already reported by this user
    const alreadyReported = commentDoc.reports.find(
      (r) => r.userId.toString() === userId
    );
    if (alreadyReported) {
      return res.status(400).json({ message: "You have already reported this comment" });
    }

    commentDoc.reports.push({ userId, reason });
    commentDoc.reportCount = commentDoc.reports.length;
    commentDoc.isFlagged = true;
    await commentDoc.save();

    return res.status(200).json({
      reported: true,
      reportCount: commentDoc.reportCount,
      message: "Comment has been reported and will be reviewed by a moderator",
    });
  } catch (error) {
    console.error("Report comment error:", error);
    return res.status(500).json({ message: "Something went wrong" });
  }
};

/**
 * Get all flagged/reported comments for admin review
 */
export const getFlaggedComments = async (req, res) => {
  try {
    const flagged = await comment
      .find({ isFlagged: true })
      .sort({ reportCount: -1 });

    return res.status(200).json({ flaggedComments: flagged });
  } catch (error) {
    console.error("Get flagged comments error:", error);
    return res.status(500).json({ message: "Something went wrong" });
  }
};

/**
 * Admin review - approve or block a flagged comment
 */
export const reviewComment = async (req, res) => {
  const { id } = req.params;
  const { action } = req.body; // "approve" or "block"

  try {
    const commentDoc = await comment.findById(id);
    if (!commentDoc) {
      return res.status(404).json({ message: "Comment not found" });
    }

    if (action === "approve") {
      commentDoc.isFlagged = false;
      commentDoc.isBlocked = false;
      commentDoc.reviewed = true;
    } else if (action === "block") {
      commentDoc.isBlocked = true;
      commentDoc.reviewed = true;
    } else {
      return res.status(400).json({ message: "Invalid action. Use 'approve' or 'block'" });
    }

    await commentDoc.save();

    return res.status(200).json({
      message: `Comment ${action === "approve" ? "approved" : "blocked"} successfully`,
      comment: commentDoc,
    });
  } catch (error) {
    console.error("Review comment error:", error);
    return res.status(500).json({ message: "Something went wrong" });
  }
};

/**
 * Delete a comment
 */
export const deletecomment = async (req, res) => {
  const { id: _id } = req.params;
  if (!mongoose.Types.ObjectId.isValid(_id)) {
    return res.status(404).send("comment unavailable");
  }
  try {
    await comment.findByIdAndDelete(_id);
    return res.status(200).json({ comment: true });
  } catch (error) {
    console.error("Delete comment error:", error);
    return res.status(500).json({ message: "Something went wrong" });
  }
};

/**
 * Edit a comment
 */
export const editcomment = async (req, res) => {
  const { id: _id } = req.params;
  const { commentbody } = req.body;
  if (!mongoose.Types.ObjectId.isValid(_id)) {
    return res.status(404).send("comment unavailable");
  }

  // Check for abuse in edited comment
  const abuseCheck = detectAbuse(commentbody);

  try {
    const updateData = { commentbody };
    if (abuseCheck.isAbusive) {
      updateData.isFlagged = true;
      updateData.isBlocked = true;
    }

    const updatedComment = await comment.findByIdAndUpdate(_id, {
      $set: updateData,
    });

    if (abuseCheck.isAbusive) {
      return res.status(200).json({
        updatedComment,
        flagged: true,
        message: "Comment edited but flagged for review due to: " + abuseCheck.reason,
      });
    }

    res.status(200).json(updatedComment);
  } catch (error) {
    console.error("Edit comment error:", error);
    return res.status(500).json({ message: "Something went wrong" });
  }
};
