import mongoose from "mongoose";

const downloadschema = mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "user",
      required: true,
    },
    videoId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "videofiles",
      required: true,
    },
    videotitle: { type: String, required: true },
    videochanel: { type: String },
    filepath: { type: String, required: true },
    filesize: { type: String },
    userPlan: {
      type: String,
      enum: ["free", "bronze", "silver", "gold"],
      default: "free",
    },
    downloadDate: { type: Date, default: Date.now },
  },
  { timestamps: true }
);

// Index for efficient daily limit queries
downloadschema.index({ userId: 1, downloadDate: -1 });

export default mongoose.model("download", downloadschema);
