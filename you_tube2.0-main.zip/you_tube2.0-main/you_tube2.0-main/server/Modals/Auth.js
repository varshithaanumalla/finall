import mongoose from "mongoose";

const userschema = mongoose.Schema({
  email: { type: String, required: true },
  name: { type: String },
  channelname: { type: String },
  description: { type: String },
  image: { type: String },
  joinedon: { type: Date, default: Date.now },

  // Feature 2: Downloads
  downloadCount: { type: Number, default: 0 },
  lastDownloadDate: { type: Date, default: null },

  // Feature 3: Subscription
  subscriptionPlan: {
    type: String,
    enum: ["free", "bronze", "silver", "gold"],
    default: "free",
  },
  subscriptionStartDate: { type: Date, default: null },
  subscriptionEndDate: { type: Date, default: null },
  razorpaySubscriptionId: { type: String, default: null },

  // Feature 5: Theme & Login Security
  theme: {
    type: String,
    enum: ["light", "dark", "auto"],
    default: "auto",
  },
  knownDevices: [{ type: String }],
  knownLocations: [{ type: String }],
  otp: { type: String, default: null },
  otpExpiry: { type: Date, default: null },
  pendingLoginData: { type: Object, default: null },
});

export default mongoose.model("user", userschema);
