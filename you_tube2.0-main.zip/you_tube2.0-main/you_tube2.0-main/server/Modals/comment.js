import mongoose from "mongoose";

const commentschema = mongoose.Schema(
  {
    userid: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "user",
      required: true,
    },
    videoid: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "videofiles",
      required: true,
    },
    commentbody: { type: String },
    usercommented: { type: String },
    commentedon: { type: Date, default: Date.now },

    // Feature 6: Multilingual Comments
    language: { type: String, default: "en" },
    location: { type: String, default: null },

    // Feature 6: Reactions
    likes: [{ type: mongoose.Schema.Types.ObjectId, ref: "user" }],
    dislikes: [{ type: mongoose.Schema.Types.ObjectId, ref: "user" }],

    // Feature 6: Moderation
    isFlagged: { type: Boolean, default: false },
    isBlocked: { type: Boolean, default: false },
    reports: [
      {
        userId: { type: mongoose.Schema.Types.ObjectId, ref: "user" },
        reason: { type: String },
        reportedAt: { type: Date, default: Date.now },
      },
    ],
    reportCount: { type: Number, default: 0 },
    reviewed: { type: Boolean, default: false },
  },
  {
    timestamps: true,
  }
);

export default mongoose.model("comment", commentschema);
