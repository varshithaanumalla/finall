import mongoose from "mongoose";

const watchpartyschema = mongoose.Schema(
  {
    hostId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "user",
      required: true,
    },
    videoId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "videofiles",
      required: true,
    },
    roomId: { type: String, required: true, unique: true },
    participants: [
      {
        userId: { type: mongoose.Schema.Types.ObjectId, ref: "user" },
        name: { type: String },
        image: { type: String },
        muted: { type: Boolean, default: false },
        cameraOff: { type: Boolean, default: false },
        joinedAt: { type: Date, default: Date.now },
      },
    ],
    messages: [
      {
        userId: { type: mongoose.Schema.Types.ObjectId, ref: "user" },
        name: { type: String },
        text: { type: String },
        sentAt: { type: Date, default: Date.now },
      },
    ],
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true }
);

export default mongoose.model("watchparty", watchpartyschema);
