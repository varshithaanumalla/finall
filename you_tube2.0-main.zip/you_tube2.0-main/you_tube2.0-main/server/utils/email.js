import nodemailer from "nodemailer";

// Unified, deployment-configurable email sender.
//
// Provider is chosen by env:
//   EMAIL_PROVIDER=resend   + RESEND_API_KEY
//   EMAIL_PROVIDER=brevo    + BREVO_API_KEY
//   EMAIL_PROVIDER=gmail    + EMAIL_USER + EMAIL_PASS (app password) / EMAIL_SERVICE
//   (unset / none)          -> Ethereal test inbox (returns a preview URL)
//
// Common options:
//   EMAIL_FROM        full "Name <addr>" (optional)
//   EMAIL_FROM_NAME   display name (default "YourTube Security")
//   EMAIL_USER        used as the from-address for gmail
//
// Returns: { delivered, provider, previewUrl }
//   delivered  - true if sent via a real provider (Resend/Brevo/Gmail)
//   previewUrl - Ethereal preview link when using the test inbox

let etherealTransporter = null;

function fromAddress() {
  const name = process.env.EMAIL_FROM_NAME || "YourTube Security";
  if (process.env.EMAIL_FROM) return process.env.EMAIL_FROM;
  // Resend's shared sender works with no domain verification.
  const addr =
    process.env.EMAIL_USER ||
    (process.env.EMAIL_PROVIDER === "resend"
      ? "onboarding@resend.dev"
      : "security@yourtube.com");
  return `${name} <${addr}>`;
}

function provider() {
  const p = (process.env.EMAIL_PROVIDER || "").toLowerCase();
  if (p) return p;
  if (process.env.RESEND_API_KEY) return "resend";
  if (process.env.BREVO_API_KEY) return "brevo";
  if (process.env.EMAIL_USER && process.env.EMAIL_PASS) return "gmail";
  return "ethereal";
}

export async function sendEmail({ to, subject, html }) {
  const prov = provider();
  const from = fromAddress();

  try {
    if (prov === "resend") {
      const res = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${process.env.RESEND_API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ from, to, subject, html }),
      });
      if (!res.ok) {
        const body = await res.text();
        throw new Error(`Resend ${res.status}: ${body}`);
      }
      console.log("Email sent via Resend to", to);
      return { delivered: true, provider: "resend", previewUrl: null };
    }

    if (prov === "brevo") {
      // Brevo expects a structured sender {name, email}.
      const name = process.env.EMAIL_FROM_NAME || "YourTube Security";
      const senderEmail = process.env.EMAIL_USER || "no-reply@yourtube.com";
      const res = await fetch("https://api.brevo.com/v3/smtp/email", {
        method: "POST",
        headers: {
          "api-key": process.env.BREVO_API_KEY,
          "Content-Type": "application/json",
          accept: "application/json",
        },
        body: JSON.stringify({
          sender: { name, email: senderEmail },
          to: [{ email: to }],
          subject,
          htmlContent: html,
        }),
      });
      if (!res.ok) {
        const body = await res.text();
        throw new Error(`Brevo ${res.status}: ${body}`);
      }
      console.log("Email sent via Brevo to", to);
      return { delivered: true, provider: "brevo", previewUrl: null };
    }

    if (prov === "gmail") {
      const transporter = process.env.EMAIL_HOST
        ? nodemailer.createTransport({
            host: process.env.EMAIL_HOST,
            port: Number(process.env.EMAIL_PORT) || 587,
            secure: String(process.env.EMAIL_SECURE) === "true",
            auth: { user: process.env.EMAIL_USER, pass: process.env.EMAIL_PASS },
          })
        : nodemailer.createTransport({
            service: process.env.EMAIL_SERVICE || "gmail",
            auth: { user: process.env.EMAIL_USER, pass: process.env.EMAIL_PASS },
          });
      const info = await transporter.sendMail({ from, to, subject, html });
      console.log("Email sent via Gmail to", to, info.messageId);
      return { delivered: true, provider: "gmail", previewUrl: null };
    }

    // Fallback: Ethereal test inbox (no real delivery, returns a preview URL).
    if (!etherealTransporter) {
      const testAccount = await nodemailer.createTestAccount();
      etherealTransporter = nodemailer.createTransport({
        host: "smtp.ethereal.email",
        port: 587,
        secure: false,
        auth: { user: testAccount.user, pass: testAccount.pass },
      });
    }
    const info = await etherealTransporter.sendMail({ from, to, subject, html });
    const previewUrl = nodemailer.getTestMessageUrl(info) || null;
    console.log("Email sent via Ethereal (test). Preview:", previewUrl);
    return { delivered: false, provider: "ethereal", previewUrl };
  } catch (error) {
    console.error(`Email send error (${prov}):`, error.message);
    return { delivered: false, provider: prov, previewUrl: null, error: error.message };
  }
}
