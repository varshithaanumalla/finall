import jwt from "jsonwebtoken";
import user from "../Modals/Auth.js";
import video from "../Modals/video.js";

const JWT_SECRET = process.env.JWT_SECRET || "yourtube_secret_key";

export async function createUser(overrides = {}) {
  return user.create({
    email: overrides.email || `user_${Date.now()}_${Math.random()}@test.com`,
    name: overrides.name || "Test User",
    image: overrides.image || "",
    ...overrides,
  });
}

export function tokenFor(userDoc) {
  return jwt.sign(
    {
      userId: userDoc._id.toString(),
      email: userDoc.email,
      name: userDoc.name,
      image: userDoc.image,
    },
    JWT_SECRET,
    { expiresIn: "1h" }
  );
}

export function authHeader(userDoc) {
  return { Authorization: `Bearer ${tokenFor(userDoc)}` };
}

export async function createVideo(overrides = {}) {
  return video.create({
    videotitle: overrides.videotitle || "Sample Video",
    filename: overrides.filename || "sample.mp4",
    filetype: overrides.filetype || "video/mp4",
    filepath: overrides.filepath || "uploads/sample.mp4",
    filesize: overrides.filesize || "1024",
    videochanel: overrides.videochanel || "Test Channel",
    uploader: overrides.uploader || "tester",
    ...overrides,
  });
}
