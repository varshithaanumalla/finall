const request = (await import("supertest")).default;
const app = (await import("../app.js")).default;
const { connectTestDB, clearTestDB, disconnectTestDB } = await import("./setup.js");

beforeAll(async () => {
  await connectTestDB();
});
afterEach(async () => {
  await clearTestDB();
});
afterAll(async () => {
  await disconnectTestDB();
});

describe("Existing application (backward compatibility)", () => {
  test("root health endpoint responds", async () => {
    const res = await request(app).get("/");
    expect(res.status).toBe(200);
    expect(res.text).toMatch(/backend is working/i);
  });

  test("legacy /user/login creates a user", async () => {
    const res = await request(app)
      .post("/user/login")
      .send({ email: "legacy@test.com", name: "Legacy" });
    expect(res.status).toBe(201);
    expect(res.body.result.email).toBe("legacy@test.com");
  });

  test("legacy /user/login returns existing user on second call", async () => {
    await request(app).post("/user/login").send({ email: "dup@test.com", name: "Dup" });
    const res = await request(app)
      .post("/user/login")
      .send({ email: "dup@test.com", name: "Dup" });
    expect(res.status).toBe(200);
    expect(res.body.result.email).toBe("dup@test.com");
  });

  test("/video/getall returns an array", async () => {
    const res = await request(app).get("/video/getall");
    expect(res.status).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
  });
});
