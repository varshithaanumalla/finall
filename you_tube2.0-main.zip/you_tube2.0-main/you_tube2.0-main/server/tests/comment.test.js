const request = (await import("supertest")).default;
const app = (await import("../app.js")).default;
const { connectTestDB, clearTestDB, disconnectTestDB } = await import("./setup.js");
const { createUser, createVideo } = await import("./helpers.js");
const comment = (await import("../Modals/comment.js")).default;

beforeAll(async () => {
  await connectTestDB();
});
afterEach(async () => {
  await clearTestDB();
});
afterAll(async () => {
  await disconnectTestDB();
});

async function postComment(videoId, userId, body, extra = {}) {
  return request(app)
    .post("/comment/postcomment")
    .send({
      videoid: videoId,
      userid: userId,
      commentbody: body,
      usercommented: "Tester",
      ...extra,
    });
}

describe("Feature 6: Multilingual Comments & Moderation", () => {
  test("clean comment is posted and visible", async () => {
    const u = await createUser();
    const v = await createVideo();
    const res = await postComment(v._id, u._id, "This is a great video");
    expect(res.status).toBe(200);

    const list = await request(app).get(`/comment/${v._id}`);
    expect(list.status).toBe(200);
    expect(list.body).toHaveLength(1);
    expect(list.body[0].commentbody).toBe("This is a great video");
  });

  test("abusive comment is flagged, blocked and hidden from the public list", async () => {
    const u = await createUser();
    const v = await createVideo();
    const res = await postComment(v._id, u._id, "you are an idiot");
    expect(res.status).toBe(201);
    expect(res.body.flagged).toBe(true);

    // Blocked comments excluded from public listing.
    const list = await request(app).get(`/comment/${v._id}`);
    expect(list.body).toHaveLength(0);

    // But present in flagged list for admin.
    const flagged = await request(app).get("/comment/flagged/all");
    expect(flagged.body.flaggedComments.length).toBeGreaterThanOrEqual(1);
  });

  test("repeated special characters (spam) are flagged", async () => {
    const u = await createUser();
    const v = await createVideo();
    const res = await postComment(v._id, u._id, "wow!!!!!!!!!");
    expect(res.status).toBe(201);
    expect(res.body.flagged).toBe(true);
  });

  test("comment translation returns translated text", async () => {
    const u = await createUser();
    const v = await createVideo();
    await postComment(v._id, u._id, "good video");
    const stored = await comment.findOne({ videoid: v._id });

    const res = await request(app)
      .post(`/comment/translate/${stored._id}`)
      .send({ targetLang: "hi" });
    expect(res.status).toBe(200);
    expect(res.body.targetLang).toBe("hi");
    expect(res.body.translated).not.toBe(res.body.original);
  });

  test("like and dislike reactions toggle and are mutually exclusive", async () => {
    const author = await createUser();
    const reactor = await createUser();
    const v = await createVideo();
    await postComment(v._id, author._id, "nice content");
    const c = await comment.findOne({ videoid: v._id });

    const like = await request(app)
      .post(`/comment/like/${c._id}`)
      .send({ userId: reactor._id.toString() });
    expect(like.status).toBe(200);
    expect(like.body.likeCount).toBe(1);

    const dislike = await request(app)
      .post(`/comment/dislike/${c._id}`)
      .send({ userId: reactor._id.toString() });
    expect(dislike.status).toBe(200);
    expect(dislike.body.dislikeCount).toBe(1);
    expect(dislike.body.likeCount).toBe(0); // like removed when disliking
  });

  test("report flags a comment for review without deleting it; admin reviews", async () => {
    const author = await createUser();
    const reporter = await createUser();
    const v = await createVideo();
    await postComment(v._id, author._id, "normal comment");
    const c = await comment.findOne({ videoid: v._id });

    const report = await request(app)
      .post(`/comment/report/${c._id}`)
      .send({ userId: reporter._id.toString(), reason: "spam" });
    expect(report.status).toBe(200);
    expect(report.body.reported).toBe(true);

    // Duplicate report by the same user rejected.
    const dup = await request(app)
      .post(`/comment/report/${c._id}`)
      .send({ userId: reporter._id.toString(), reason: "spam" });
    expect(dup.status).toBe(400);

    // Comment still exists and is flagged (not auto-deleted).
    const stillThere = await comment.findById(c._id);
    expect(stillThere).not.toBeNull();
    expect(stillThere.isFlagged).toBe(true);

    // Admin blocks it.
    const review = await request(app)
      .post(`/comment/review/${c._id}`)
      .send({ action: "block" });
    expect(review.status).toBe(200);
    const blocked = await comment.findById(c._id);
    expect(blocked.isBlocked).toBe(true);
    expect(blocked.reviewed).toBe(true);
  });
});
