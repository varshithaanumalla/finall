const request = (await import("supertest")).default;
const app = (await import("../app.js")).default;
const { connectTestDB, clearTestDB, disconnectTestDB } = await import("./setup.js");
const { createUser, createVideo, authHeader } = await import("./helpers.js");

beforeAll(async () => {
  await connectTestDB();
});
afterEach(async () => {
  await clearTestDB();
});
afterAll(async () => {
  await disconnectTestDB();
});

describe("Feature 1: Watch Party", () => {
  test("watch party routes require authentication", async () => {
    const res = await request(app).post("/watchparty/create").send({});
    expect(res.status).toBe(401);
  });

  test("full watch party workflow: host creates, guest joins, chats, leaves", async () => {
    const host = await createUser({ name: "Host" });
    const guest = await createUser({ name: "Guest" });
    const v = await createVideo();

    // 1. Host creates a party
    const createRes = await request(app)
      .post("/watchparty/create")
      .set(authHeader(host))
      .send({ videoId: v._id });
    expect(createRes.status).toBe(201);
    const roomId = createRes.body.party.roomId;
    expect(roomId).toBeTruthy();
    expect(createRes.body.party.participants).toHaveLength(1);

    // 2. Guest joins
    const joinRes = await request(app)
      .post(`/watchparty/join/${roomId}`)
      .set(authHeader(guest))
      .send();
    expect(joinRes.status).toBe(200);
    expect(joinRes.body.party.participants).toHaveLength(2);

    // 3. Participant list retrievable
    const getRes = await request(app)
      .get(`/watchparty/party/${roomId}`)
      .set(authHeader(guest));
    expect(getRes.status).toBe(200);
    expect(getRes.body.party.participants.map((p) => p.name)).toContain("Guest");

    // 4. Chat message exchange
    await request(app)
      .post(`/watchparty/message/${roomId}`)
      .set(authHeader(guest))
      .send({ text: "Hello everyone" });
    const msgRes = await request(app)
      .get(`/watchparty/messages/${roomId}`)
      .set(authHeader(host));
    expect(msgRes.body.messages).toHaveLength(1);
    expect(msgRes.body.messages[0].text).toBe("Hello everyone");

    // 5. Mute/camera status update
    const statusRes = await request(app)
      .patch(`/watchparty/status/${roomId}`)
      .set(authHeader(guest))
      .send({ muted: true, cameraOff: true });
    expect(statusRes.status).toBe(200);
    expect(statusRes.body.participant.muted).toBe(true);
    expect(statusRes.body.participant.cameraOff).toBe(true);

    // 6. Guest leaves
    const leaveRes = await request(app)
      .post(`/watchparty/leave/${roomId}`)
      .set(authHeader(guest))
      .send();
    expect(leaveRes.status).toBe(200);

    // 7. Host leaving ends the party
    const hostLeave = await request(app)
      .post(`/watchparty/leave/${roomId}`)
      .set(authHeader(host))
      .send();
    expect(hostLeave.status).toBe(200);

    // Party is now inactive -> not found
    const afterEnd = await request(app)
      .get(`/watchparty/party/${roomId}`)
      .set(authHeader(host));
    expect(afterEnd.status).toBe(404);
  });

  test("joining a non-existent party returns 404", async () => {
    const u = await createUser();
    const res = await request(app)
      .post("/watchparty/join/does_not_exist")
      .set(authHeader(u))
      .send();
    expect(res.status).toBe(404);
  });
});
