import mongoose from "mongoose";

// Test DB bootstrap.
//
// Strategy:
//   - If TEST_DB_URL / DB_URL points at a reachable MongoDB (e.g. the `mongodb`
//     service inside docker-compose), connect to it directly. This is the path
//     used for `docker compose run test`.
//   - Otherwise fall back to an in-memory MongoDB instance
//     (mongodb-memory-server) for local developer runs.
//
// Either way, collections are cleared between tests so no development data is
// touched and tests stay isolated.

let memoryServer = null;

export async function connectTestDB() {
  const explicitUrl = process.env.TEST_DB_URL || process.env.DB_URL;

  // Only treat the provided URL as usable when NODE_ENV is test and a URL is set.
  if (explicitUrl) {
    // Ensure we never write to a non-test database by name.
    let url = explicitUrl;
    if (!/test/i.test(url)) {
      // Append a test-specific db name to avoid clobbering dev data.
      url = url.replace(/\/?$/, "").replace(/\/[^/]*$/, "") + "/yourtube_test";
    }
    try {
      await mongoose.connect(url, { serverSelectionTimeoutMS: 3000 });
      return;
    } catch (err) {
      // Fall through to in-memory server if the external DB is unreachable.
      // eslint-disable-next-line no-console
      console.warn(
        "External test DB unreachable, falling back to in-memory MongoDB:",
        err.message
      );
    }
  }

  const { MongoMemoryServer } = await import("mongodb-memory-server");
  memoryServer = await MongoMemoryServer.create();
  await mongoose.connect(memoryServer.getUri(), { dbName: "yourtube_test" });
}

export async function clearTestDB() {
  const collections = mongoose.connection.collections;
  for (const key of Object.keys(collections)) {
    await collections[key].deleteMany({});
  }
}

export async function disconnectTestDB() {
  await mongoose.connection.dropDatabase().catch(() => {});
  await mongoose.disconnect();
  if (memoryServer) {
    await memoryServer.stop();
    memoryServer = null;
  }
}
