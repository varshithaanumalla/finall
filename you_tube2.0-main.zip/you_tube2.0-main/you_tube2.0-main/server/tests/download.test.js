import { jest } from "@jest/globals";

const request = (await import("supertest")).default;
const app = (await import("../app.js")).default;
const { connectTestDB, clearTestDB, disconnectTestDB } = await import("./setup.js");
const { createUser, createVideo, authHeader } = await import("./helpers.js");
const download = (await import("../Modals/download.js")).default;

beforeAll(async () => {
  await connectTestDB();
});
afterEach(async () => {
  await clearTestDB();
});
afterAll(async () => {
  await disconnectTestDB();
});

describe("Feature 2: Controlled Video Downloads", () => {
  test("download routes require authentication", async () => {
    const res = await request(app).get("/downloads/stats");
    expect(res.status).toBe(401);
  });

  test("free user has a daily limit of 1 download", async () => {
    const u = await createUser({ subscriptionPlan: "free" });
    const v = await createVideo();
    const res = await request(app)
      .get(`/downloads/check/${v._id}`)
      .set(authHeader(u));
    expect(res.status).toBe(200);
    expect(res.body.plan).toBe("free");
    expect(res.body.limit).toBe(1);
    expect(res.body.canDownload).toBe(true);
    expect(res.body.remaining).toBe(1);
  });

  test("free user blocked after reaching daily limit (restriction path)", async () => {
    const u = await createUser({ subscriptionPlan: "free" });
    const v = await createVideo();

    // Seed one download for today -> limit reached
    await download.create({
      userId: u._id,
      videoId: v._id,
      videotitle: v.videotitle,
      videochanel: v.videochanel,
      filepath: v.filepath,
      filesize: v.filesize,
      userPlan: "free",
      downloadDate: new Date(),
    });

    const checkRes = await request(app)
      .get(`/downloads/check/${v._id}`)
      .set(authHeader(u));
    expect(checkRes.body.canDownload).toBe(false);
    expect(checkRes.body.remaining).toBe(0);

    // Attempting an actual download should be rejected with 403
    const dlRes = await request(app)
      .get(`/downloads/download/${v._id}`)
      .set(authHeader(u));
    expect(dlRes.status).toBe(403);
    expect(dlRes.body.message).toMatch(/limit/i);
  });

  test("gold user has a higher daily limit (50)", async () => {
    const u = await createUser({ subscriptionPlan: "gold" });
    const v = await createVideo();
    const res = await request(app)
      .get(`/downloads/check/${v._id}`)
      .set(authHeader(u));
    expect(res.body.limit).toBe(50);
    expect(res.body.canDownload).toBe(true);
  });

  test("Downloads section lists the user's downloads", async () => {
    const u = await createUser({ subscriptionPlan: "bronze" });
    const v = await createVideo({ videotitle: "My Download" });
    await download.create({
      userId: u._id,
      videoId: v._id,
      videotitle: v.videotitle,
      videochanel: v.videochanel,
      filepath: v.filepath,
      filesize: v.filesize,
      userPlan: "bronze",
      downloadDate: new Date(),
    });

    const res = await request(app)
      .get("/downloads/user-downloads")
      .set(authHeader(u));
    expect(res.status).toBe(200);
    expect(res.body.downloads).toHaveLength(1);
    expect(res.body.downloads[0].videotitle).toBe("My Download");
    expect(res.body.downloads[0].userPlan).toBe("bronze");
  });

  test("stats reflect plan, daily limit and counts", async () => {
    const u = await createUser({ subscriptionPlan: "silver" });
    const res = await request(app).get("/downloads/stats").set(authHeader(u));
    expect(res.status).toBe(200);
    expect(res.body.plan).toBe("silver");
    expect(res.body.dailyLimit).toBe(25);
    expect(res.body.todayCount).toBe(0);
  });
});
