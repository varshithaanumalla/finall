import { jest } from "@jest/globals";
import crypto from "crypto";

// Provide valid-looking Razorpay keys so createOrder uses the (mocked)
// Razorpay client instead of the demo-mode fallback.
process.env.RAZORPAY_KEY_ID = "rzp_test_realkey123";
process.env.RAZORPAY_KEY_SECRET = "realsecretkey1234567";

// ---- Mock external services BEFORE importing the app ----
const mockOrdersCreate = jest.fn(async (opts) => ({
  id: "order_test_123",
  amount: opts.amount,
  currency: opts.currency,
  receipt: opts.receipt,
}));

jest.unstable_mockModule("razorpay", () => ({
  default: class RazorpayMock {
    constructor() {
      this.orders = { create: mockOrdersCreate };
    }
  },
}));

const sendMailMock = jest.fn(async () => ({ messageId: "mock-message-id" }));
jest.unstable_mockModule("nodemailer", () => ({
  default: {
    createTransport: () => ({ sendMail: sendMailMock }),
    createTestAccount: async () => ({ user: "test", pass: "test" }),
    getTestMessageUrl: () => null,
  },
}));

const request = (await import("supertest")).default;
const app = (await import("../app.js")).default;
const { connectTestDB, clearTestDB, disconnectTestDB } = await import("./setup.js");
const { createUser, authHeader } = await import("./helpers.js");
const user = (await import("../Modals/Auth.js")).default;

const RAZORPAY_SECRET = process.env.RAZORPAY_KEY_SECRET || "XXXXXXXXXXXXXXXXXXXX";

beforeAll(async () => {
  await connectTestDB();
});
afterEach(async () => {
  await clearTestDB();
  jest.clearAllMocks();
});
afterAll(async () => {
  await disconnectTestDB();
});

describe("Feature 3: Subscription Upgrade", () => {
  test("GET /subscription/plans returns all four plans (public)", async () => {
    const res = await request(app).get("/subscription/plans");
    expect(res.status).toBe(200);
    expect(res.body.plans).toHaveProperty("free");
    expect(res.body.plans).toHaveProperty("bronze");
    expect(res.body.plans).toHaveProperty("silver");
    expect(res.body.plans).toHaveProperty("gold");
    expect(res.body.plans.gold.price).toBe(499);
  });

  test("create-order requires authentication", async () => {
    const res = await request(app).post("/subscription/create-order").send({ planId: "bronze" });
    expect(res.status).toBe(401);
  });

  test("create-order rejects free plan", async () => {
    const u = await createUser();
    const res = await request(app)
      .post("/subscription/create-order")
      .set(authHeader(u))
      .send({ planId: "free" });
    expect(res.status).toBe(400);
  });

  test("full subscription workflow: order -> verify -> plan activated + email sent", async () => {
    const u = await createUser({ email: "sub@test.com" });

    // 1. Create order
    const orderRes = await request(app)
      .post("/subscription/create-order")
      .set(authHeader(u))
      .send({ planId: "gold" });
    expect(orderRes.status).toBe(200);
    expect(orderRes.body.orderId).toBe("order_test_123");
    expect(mockOrdersCreate).toHaveBeenCalledTimes(1);

    // 2. Simulate Razorpay payment + valid signature
    const razorpayPaymentId = "pay_test_456";
    const signature = crypto
      .createHmac("sha256", RAZORPAY_SECRET)
      .update(orderRes.body.orderId + "|" + razorpayPaymentId)
      .digest("hex");

    const verifyRes = await request(app)
      .post("/subscription/verify-payment")
      .set(authHeader(u))
      .send({
        razorpayOrderId: orderRes.body.orderId,
        razorpayPaymentId,
        razorpaySignature: signature,
        planId: "gold",
      });
    expect(verifyRes.status).toBe(200);
    expect(verifyRes.body.user.subscriptionPlan).toBe("gold");

    // 3. DB reflects the upgrade
    const updated = await user.findById(u._id);
    expect(updated.subscriptionPlan).toBe("gold");
    expect(updated.subscriptionEndDate).toBeTruthy();

    // 4. Confirmation email attempted
    expect(sendMailMock).toHaveBeenCalledTimes(1);
  });

  test("verify-payment with invalid signature and no matching order is rejected", async () => {
    const u = await createUser();
    const res = await request(app)
      .post("/subscription/verify-payment")
      .set(authHeader(u))
      .send({
        razorpayOrderId: "nonexistent_order",
        razorpayPaymentId: "pay_x",
        razorpaySignature: "badsignature",
        planId: "silver",
      });
    expect(res.status).toBe(400);
  });

  test("GET /subscription/current returns the active plan", async () => {
    const u = await createUser({ subscriptionPlan: "silver" });
    const res = await request(app).get("/subscription/current").set(authHeader(u));
    expect(res.status).toBe(200);
    expect(res.body.currentPlan).toBe("silver");
  });
});
