import { jest } from "@jest/globals";

const sendMailMock = jest.fn(async () => ({ messageId: "mock-otp-id" }));
jest.unstable_mockModule("nodemailer", () => ({
  default: {
    createTransport: () => ({ sendMail: sendMailMock }),
    createTestAccount: async () => ({ user: "test", pass: "test" }),
    getTestMessageUrl: () => null,
  },
}));

const request = (await import("supertest")).default;
const app = (await import("../app.js")).default;
const { connectTestDB, clearTestDB, disconnectTestDB } = await import("./setup.js");
const { createUser, authHeader } = await import("./helpers.js");
const user = (await import("../Modals/Auth.js")).default;

beforeAll(async () => {
  await connectTestDB();
});
afterEach(async () => {
  await clearTestDB();
  jest.clearAllMocks();
});
afterAll(async () => {
  await disconnectTestDB();
});

describe("Feature 5: Personalized Theme & Login Security", () => {
  test("new user login returns a token, a theme and requires no OTP", async () => {
    const res = await request(app)
      .post("/user/login-secure")
      .send({
        email: "new@test.com",
        name: "New User",
        city: "Mumbai",
        state: "MH",
        device: "device-1",
      });
    expect(res.status).toBe(201);
    expect(res.body.token).toBeTruthy();
    expect(res.body.requiresOTP).toBe(false);
    expect(["light", "dark"]).toContain(res.body.theme);
  });

  test("known user from a known device/location logs in without OTP", async () => {
    await request(app).post("/user/login-secure").send({
      email: "known@test.com",
      name: "Known",
      city: "Delhi",
      state: "DL",
      device: "dev-known",
    });
    const res = await request(app).post("/user/login-secure").send({
      email: "known@test.com",
      name: "Known",
      city: "Delhi",
      state: "DL",
      device: "dev-known",
    });
    expect(res.status).toBe(200);
    expect(res.body.requiresOTP).toBe(false);
    expect(res.body.token).toBeTruthy();
  });

  test("login from a new device triggers OTP, and verify completes login", async () => {
    // Initial login establishes known device/location.
    await request(app).post("/user/login-secure").send({
      email: "otp@test.com",
      name: "OTP User",
      city: "Pune",
      state: "MH",
      device: "trusted-device",
    });

    // New device -> OTP required.
    const otpRes = await request(app).post("/user/login-secure").send({
      email: "otp@test.com",
      name: "OTP User",
      city: "Pune",
      state: "MH",
      device: "new-suspicious-device",
    });
    expect(otpRes.status).toBe(200);
    expect(otpRes.body.requiresOTP).toBe(true);
    expect(sendMailMock).toHaveBeenCalledTimes(1);

    // Read the stored OTP (simulating the user reading their email).
    const stored = await user.findOne({ email: "otp@test.com" });
    expect(stored.otp).toBeTruthy();

    // Wrong OTP rejected.
    const wrong = await request(app)
      .post("/user/verify-otp")
      .send({ email: "otp@test.com", otp: "000000" });
    expect(wrong.status).toBe(400);

    // Correct OTP completes login.
    const verify = await request(app)
      .post("/user/verify-otp")
      .send({ email: "otp@test.com", otp: stored.otp });
    expect(verify.status).toBe(200);
    expect(verify.body.token).toBeTruthy();

    // Device now trusted -> OTP cleared.
    const after = await user.findOne({ email: "otp@test.com" });
    expect(after.otp).toBeNull();
    expect(after.knownDevices).toContain("new-suspicious-device");
  });

  test("manual theme preference is saved and takes precedence", async () => {
    const u = await createUser({ theme: "auto" });

    const update = await request(app)
      .patch("/theme/update")
      .set(authHeader(u))
      .send({ theme: "light" });
    expect(update.status).toBe(200);
    expect(update.body.theme).toBe("light");

    const current = await request(app).get("/theme/current").set(authHeader(u));
    expect(current.status).toBe(200);
    expect(current.body.theme).toBe("light");
    expect(current.body.effectiveTheme).toBe("light");

    const persisted = await user.findById(u._id);
    expect(persisted.theme).toBe("light");
  });

  test("invalid theme value is rejected", async () => {
    const u = await createUser();
    const res = await request(app)
      .patch("/theme/update")
      .set(authHeader(u))
      .send({ theme: "neon" });
    expect(res.status).toBe(400);
  });
});
