import express from "express";
import {
  createParty,
  joinParty,
  leaveParty,
  getParty,
  addMessage,
  getMessages,
  updateParticipantStatus,
  getUserParties,
} from "../controllers/watchparty.js";
import { verifyToken } from "../middleware/auth.js";

const routes = express.Router();

// All watch party routes require authentication
routes.post("/create", verifyToken, createParty);
routes.post("/join/:roomId", verifyToken, joinParty);
routes.post("/leave/:roomId", verifyToken, leaveParty);
routes.get("/party/:roomId", verifyToken, getParty);
routes.post("/message/:roomId", verifyToken, addMessage);
routes.get("/messages/:roomId", verifyToken, getMessages);
routes.patch("/status/:roomId", verifyToken, updateParticipantStatus);
routes.get("/user-parties", verifyToken, getUserParties);

export default routes;
