import express from "express";
import {
  getPlans,
  createOrder,
  verifyPayment,
  getCurrentSubscription,
  getSubscriptionHistory,
} from "../controllers/subscription.js";
import { verifyToken } from "../middleware/auth.js";

const routes = express.Router();

// Get plans is public
routes.get("/plans", getPlans);

// All other subscription routes require authentication
routes.post("/create-order", verifyToken, createOrder);
routes.post("/verify-payment", verifyToken, verifyPayment);
routes.get("/current", verifyToken, getCurrentSubscription);
routes.get("/history", verifyToken, getSubscriptionHistory);

export default routes;
