import express from "express";
import { verifyToken } from "../middleware/auth.js";
import { updateTheme, getTheme } from "../controllers/themeSecurity.js";

const routes = express.Router();

// All theme routes require authentication
routes.patch("/update", verifyToken, updateTheme);
routes.get("/current", verifyToken, getTheme);

export default routes;
