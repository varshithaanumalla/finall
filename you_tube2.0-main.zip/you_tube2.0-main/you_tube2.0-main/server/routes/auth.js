import express from "express";
import { login, updateprofile } from "../controllers/auth.js";
import { loginWithSecurity, verifyOTP } from "../controllers/themeSecurity.js";
import { verifyToken } from "../middleware/auth.js";

const routes = express.Router();

// Existing routes (backward compatibility)
routes.post("/login", login);
routes.patch("/update/:id", updateprofile);

// Feature 5: Login security with OTP
routes.post("/login-secure", loginWithSecurity);
routes.post("/verify-otp", verifyOTP);

export default routes;
