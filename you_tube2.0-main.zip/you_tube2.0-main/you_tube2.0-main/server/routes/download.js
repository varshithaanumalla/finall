import express from "express";
import {
  checkDownloadLimit,
  downloadVideo,
  getUserDownloads,
  getDownloadStats,
} from "../controllers/download.js";
import { verifyToken } from "../middleware/auth.js";

const routes = express.Router();

// All download routes require authentication
routes.get("/check/:videoId", verifyToken, checkDownloadLimit);
routes.get("/download/:videoId", verifyToken, downloadVideo);
routes.get("/user-downloads", verifyToken, getUserDownloads);
routes.get("/stats", verifyToken, getDownloadStats);

export default routes;
