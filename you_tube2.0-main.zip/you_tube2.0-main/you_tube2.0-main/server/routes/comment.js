import express from "express";
import {
  deletecomment,
  getallcomment,
  postcomment,
  editcomment,
  translateComment,
  likeComment,
  dislikeComment,
  reportComment,
  getFlaggedComments,
  reviewComment,
} from "../controllers/comment.js";

const routes = express.Router();

// Existing routes
routes.get("/:videoid", getallcomment);
routes.post("/postcomment", postcomment);
routes.delete("/deletecomment/:id", deletecomment);
routes.post("/editcomment/:id", editcomment);

// Feature 6: Multilingual & Moderation routes
routes.post("/translate/:id", translateComment);
routes.post("/like/:id", likeComment);
routes.post("/dislike/:id", dislikeComment);
routes.post("/report/:id", reportComment);
routes.get("/flagged/all", getFlaggedComments);
routes.post("/review/:id", reviewComment);

export default routes;
