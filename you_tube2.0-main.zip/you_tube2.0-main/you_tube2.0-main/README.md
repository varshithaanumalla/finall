# YourTube 2.0

A YouTube‑style video‑streaming platform: an **Express + MongoDB** backend and a
**Next.js** frontend. This repository extends the original app with six feature
sets, a real‑time watch party, a Jest/Supertest test suite, and a fully
Dockerised dev/test environment.

> This project **extends an existing codebase** — it is not a rewrite. The
> original user, video, auth, comment, like, history and watch‑later features
> are preserved and remain backward compatible.

---

## Project Overview

| Layer    | Technology                                                       | Location     |
|----------|------------------------------------------------------------------|--------------|
| Backend  | Node.js (ES modules), Express 5, Mongoose 8, Socket.IO, JWT      | `./server`   |
| Frontend | Next.js 15 (Pages Router), React 19, Tailwind, socket.io‑client  | `./yourtube` |
| Database | MongoDB 7                                                        | container    |
| Payments | Razorpay (test mode) — with a built‑in demo checkout fallback    | backend      |
| Email    | Pluggable: Resend / Brevo / Gmail SMTP / Ethereal (test inbox)   | backend      |

The backend keeps the existing **MVC structure** (`routes/`, `controllers/`,
`Modals/`, `middleware/`). The Express app is defined in `server/app.js`
(exported for tests); `server/index.js` adds the HTTP server, Socket.IO and the
MongoDB connection on top of it.

---

## Features Implemented

### 1. Watch Party (real‑time video call)
Host creates a party, authenticated users join by Room ID, see each other's live
**camera** and **screen share**, exchange **chat**, toggle mute/camera, and leave.
WebRTC uses the **perfect‑negotiation pattern** with targeted Socket.IO signalling,
an ICE‑candidate queue, and `onnegotiationneeded` renegotiation (so screen‑share
swaps reliably). Remote tiles support **click‑to‑expand full‑screen (Zoom‑style)**
and an **Unmute** control (browser autoplay policy). Chat is persisted; the host
leaving / disconnecting ends the party and notifies peers.

### 2. Controlled Video Downloads
Daily download limits per plan, counted on the **IST calendar day**:
`free = 1`, `bronze = 10`, `silver = 25`, `gold = 50`. Downloads are recorded
(user, plan, video, date) and shown in the profile **Downloads** section.
Free users are blocked with HTTP `403` once the daily limit is reached. The
browser download is an **authenticated blob fetch** (sends the JWT), not a plain
link.

### 3. Subscription Upgrade (Razorpay)
Free / Bronze / Silver / Gold plans: create order → verify payment → activate
plan → **email an invoice**. Two modes, auto‑detected:
- **Real Razorpay** when valid test keys are configured (real checkout popup).
- **Demo checkout** otherwise — a built‑in Razorpay‑style modal (card fields,
  test card, Pay button) so the full flow works with **no Razorpay account**.

### 4. Custom Video Player
Play/pause, volume, fullscreen, **±10s seek** (buttons + arrow keys), **double‑tap /
double‑click** left=‑10s / right=+10s with on‑screen feedback, duration/current
time, loading spinner, and a **Next video** button. Free users see a **pre‑roll ad
+ ad banner + "480p" badge**; paid users are **ad‑free** with a plan‑based quality
badge (720p/1080p/4K).

### 5. Personalized Theme & Login Security
Default theme resolves from **IST time** (light 10:00–11:59 AM, dark otherwise),
saved to the user profile and manually overridable. Applied on login from the
server's effective theme. Logins from a **new city/state/device** trigger an
**email OTP** (gated by `OTP_ENABLED`).

### 6. Multilingual Comments & Moderation
Post comments in any language; **Translate** any comment via a real translation
API (dictionary fallback). Shows username + posted time; **optional** location for
privacy. Detects and **blocks** abusive words / spam / repeated special characters.
**Like / dislike / report** — reports **flag for review** (never auto‑delete).

---

## Prerequisites

Only **Docker Desktop** is required — no local Node.js or MongoDB.
- Docker Engine 24+ (tested with Docker 29.x) and Docker Compose v2.

(A no‑Docker path is described under **Running Without Docker** below.)

---

## Quick Start (Docker)

```bash
# 1. From the project root
cp .env.example .env        # then edit as needed (see Environment below)

# 2. Start the whole app (mongodb + backend + frontend)
docker compose up --build   # first run
# subsequent runs:
docker compose up
```

Open **http://localhost:3000**.

### Seed sample videos (optional, recommended)
The database starts empty. To load 10 distinct sample videos (one per category):
```bash
docker compose exec backend node seed.js
```

---

## Two Commands You Must Not Confuse

| Command | What it does |
|---------|--------------|
| `docker compose up -d` | Starts the **full app** (mongodb + backend + frontend) |
| `docker compose run --rm test` | Runs **only the test suite** (mongodb + test container). Does **NOT** start the app. |

After running tests, bring the app back with `docker compose up -d`.

---

## Application URLs

| Service  | URL                    |
|----------|------------------------|
| Frontend | http://localhost:3000  |
| Backend  | http://localhost:5000  |
| Health   | http://localhost:5000/ |

MongoDB runs in its own container (port published only for local inspection).

---

## Environment Configuration

All config lives in `.env` at the project root (gitignored). Template:
`.env.example`. Compose passes these to the containers.

| Variable | Purpose |
|----------|---------|
| `DB_URL` | Mongo connection (default `mongodb://mongodb:27017/yourtube`) |
| `JWT_SECRET` | JWT signing secret |
| `OTP_ENABLED` | `true`/`false` — require OTP on new device/location |
| `EMAIL_PROVIDER` | `resend` / `brevo` / `gmail` / blank (= Ethereal test inbox) |
| `RESEND_API_KEY` | Resend key (if provider=resend) |
| `BREVO_API_KEY` | Brevo key (if provider=brevo) |
| `EMAIL_USER` / `EMAIL_PASS` | Gmail sender + 16‑char app password (if provider=gmail) |
| `EMAIL_FROM` | Full sender, e.g. `YourTube <onboarding@resend.dev>` |
| `EMAIL_FROM_NAME` | Display name on emails |
| `RAZORPAY_KEY_ID` / `RAZORPAY_KEY_SECRET` | Razorpay test keys (blank/placeholder = demo checkout) |
| `THEME_TEST_HOUR` | **Dev‑only:** force an IST hour (e.g. `10` = light) to demo the theme. Remove for real clock. |
| `FRONTEND_URL` | CORS origin for Socket.IO |
| `BACKEND_URL` | Backend base URL for the browser (frontend) |

> After editing `.env`, apply it with:
> `docker compose up -d --force-recreate backend` (a plain restart won't reload env).

### Email setup (for real OTP + invoice delivery)
Emails send through whichever provider you configure. Easiest is **Resend**
(free, instant key): sign up at resend.com → create an API key → set
`EMAIL_PROVIDER=resend`, `RESEND_API_KEY=re_...`, and
`EMAIL_FROM=YourTube <onboarding@resend.dev>`.
On Resend's free tier (no verified domain) emails deliver only to your **account
signup address**; verify a domain to send to anyone. With no provider set, the app
falls back to an **Ethereal** test inbox (and an in‑app email preview) so OTP/invoice
still work for demos.

### Razorpay setup (optional)
Leave the placeholder keys to use the **demo checkout** (works with no account).
To use the real Razorpay popup, put test keys from the Razorpay dashboard
(Test Mode) into `RAZORPAY_KEY_ID` / `RAZORPAY_KEY_SECRET` and
`NEXT_PUBLIC_RAZORPAY_KEY_ID`.

---

## Running Automated Tests

Tests run inside Docker against an **isolated** `yourtube_test` database, with
Razorpay and email **mocked**. Development data is never touched.

```bash
docker compose run --rm --build test
```

Latest result:
```
Test Suites: 6 passed, 6 total
Tests:       30 passed, 30 total
```
Suites: `existing`, `subscription`, `download`, `watchparty`, `themeSecurity`,
`comment`. Failing tests return a non‑zero exit code (CI‑safe).

> After testing, restart the app: `docker compose up -d`.

---

## API Endpoints (base `http://localhost:5000`)

### Users / Auth
| Method | Path | Auth | Description |
|--------|------|------|-------------|
| POST | `/user/login` | no | Legacy login / create user |
| PATCH | `/user/update/:id` | no | Update channel name / description |
| POST | `/user/login-secure` | no | Login with theme + new‑device OTP check |
| POST | `/user/verify-otp` | no | Verify OTP and complete login |

### Videos
| Method | Path | Auth | Description |
|--------|------|------|-------------|
| POST | `/video/upload` | no | Upload an mp4 |
| GET | `/video/getall` | no | List all videos |

### Theme (Feature 5)
| Method | Path | Auth | Description |
|--------|------|------|-------------|
| PATCH | `/theme/update` | yes | Set theme (`light`/`dark`/`auto`) |
| GET | `/theme/current` | yes | Stored + effective theme |

### Subscriptions (Feature 3)
| Method | Path | Auth | Description |
|--------|------|------|-------------|
| GET | `/subscription/plans` | no | List plans |
| POST | `/subscription/create-order` | yes | Create order (real or demo) |
| POST | `/subscription/verify-payment` | yes | Verify + activate + email invoice |
| GET | `/subscription/current` | yes | Current plan |
| GET | `/subscription/history` | yes | Subscription history |

### Downloads (Feature 2)
| Method | Path | Auth | Description |
|--------|------|------|-------------|
| GET | `/downloads/check/:videoId` | yes | Can download today? |
| GET | `/downloads/download/:videoId` | yes | Download (auth'd stream) |
| GET | `/downloads/user-downloads` | yes | Downloads list |
| GET | `/downloads/stats` | yes | Plan / limit / counts |

### Watch Party (Feature 1)
| Method | Path | Auth | Description |
|--------|------|------|-------------|
| POST | `/watchparty/create` | yes | Create party |
| POST | `/watchparty/join/:roomId` | yes | Join |
| POST | `/watchparty/leave/:roomId` | yes | Leave |
| GET | `/watchparty/party/:roomId` | yes | Party + participants |
| POST | `/watchparty/message/:roomId` | yes | Add chat message |
| GET | `/watchparty/messages/:roomId` | yes | List messages |
| PATCH | `/watchparty/status/:roomId` | yes | Mute/camera status |
| GET | `/watchparty/user-parties` | yes | Active parties for user |

Socket.IO events: `join-party`, `offer`, `answer`, `ice-candidate`,
`party-message`, `screen-share-start/stop`, `play`, `pause`, `seek`,
`toggle-mute`, `toggle-camera`, `leave-party`, `user-joined`, `user-left`.

### Comments (Feature 6)
| Method | Path | Auth | Description |
|--------|------|------|-------------|
| GET | `/comment/:videoid` | no | Public comments (blocked excluded) |
| POST | `/comment/postcomment` | no | Post (lang detect + abuse filter) |
| POST | `/comment/editcomment/:id` | no | Edit |
| DELETE | `/comment/deletecomment/:id` | no | Delete |
| POST | `/comment/translate/:id` | no | Translate |
| POST | `/comment/like/:id` | no | Like |
| POST | `/comment/dislike/:id` | no | Dislike |
| POST | `/comment/report/:id` | no | Report (flag for review) |
| GET | `/comment/flagged/all` | no | Flagged comments (admin) |
| POST | `/comment/review/:id` | no | Approve / block |

---

## Docker Operations

```bash
docker compose logs -f              # all logs
docker compose logs -f backend      # one service
docker compose stop                 # stop (keep data)
docker compose down                 # remove containers + network (keep volumes)
docker compose down -v              # also wipe DB + uploads volumes
```

### Utility scripts
```bash
docker compose exec backend node seed.js          # seed 10 sample videos
docker compose exec backend node resetusers.js    # delete all users + related data (keep videos)
bash reset-users.sh                                # same, with a confirmation prompt
```

### Persistent storage (named volumes)
`mongodb_data` (DB), `uploads_data` (uploaded videos),
`backend_node_modules` / `frontend_node_modules` / `frontend_next` (deps/build).

---

## Running Without Docker

Install **Node.js 20** and **MongoDB** (or use MongoDB Atlas), then:

```bash
# Backend
cd server
npm install
# create server/.env:  PORT=5000  DB_URL=mongodb://localhost:27017/yourtube
#                       JWT_SECRET=...  OTP_ENABLED=false
npm run dev        # http://localhost:5000

# Frontend (second terminal)
cd yourtube
npm install
# create yourtube/.env:  BACKEND_URL=http://localhost:5000
npm run dev        # http://localhost:3000

# Seed videos
cd server && node seed.js
```

> Do **not** copy `node_modules` between machines — run `npm install` on each.

---

## Known Limitations

- **Email free tier:** Resend (no verified domain) delivers only to your signup
  address; other recipients fall back to the in‑app/Ethereal preview. Verify a
  domain (or use Brevo/Gmail) for universal delivery.
- **OTP via SMS** is not integrated — email OTP only.
- **Video quality labels** (720p/1080p/4K) are plan badges, not real multi‑bitrate
  transcoding (one file is served per video).
- **Watch Party video call** requires camera/mic permission; "share‑then‑join"
  (sharing before a peer joins) shows the camera to the late joiner until the next
  renegotiation.
- **Translation** uses a free public endpoint that can rate‑limit (429); it then
  falls back to a small dictionary.
- **Razorpay** runs in test/demo mode; no real transactions.
- `THEME_TEST_HOUR` is a **dev override** — remove it so the theme uses the real
  clock.

---

## Repository Layout

```
.
├── docker-compose.yml        # mongodb, backend, frontend, test services
├── .env.example              # environment template
├── reset-users.sh            # convenience wrapper for resetusers.js
├── server/                   # Express + MongoDB backend
│   ├── app.js  index.js
│   ├── routes/ controllers/ Modals/ middleware/ utils/
│   ├── tests/                # Jest + Supertest suite
│   ├── seed.js  resetusers.js
│   ├── Dockerfile  Dockerfile.test
└── yourtube/                 # Next.js frontend
    ├── src/components/        # VideoPlayer, WatchParty, Comments, SubscriptionPlans, …
    └── Dockerfile
```
