#!/usr/bin/env bash
#
# reset-users.sh
# ----------------------------------------------------------------------------
# DESTRUCTIVE: deletes ALL users and their related data (subscriptions,
# downloads, comments, watch parties) from the running MongoDB. Videos are
# kept. Use to get a clean testing slate.
#
# Usage (from the project root, with the stack running):
#   bash reset-users.sh
#
# Requires: docker compose stack up (backend + mongodb).
# ----------------------------------------------------------------------------
set -e

echo "⚠️  This will DELETE ALL USERS and their subscriptions, downloads,"
echo "    comments, and watch parties (videos are kept)."
read -r -p "Continue? [y/N] " answer

case "$answer" in
  [yY][eE][sS]|[yY])
    echo "Resetting users..."
    docker compose exec -T backend node resetusers.js
    echo "✅ Done."
    ;;
  *)
    echo "Aborted."
    ;;
esac
