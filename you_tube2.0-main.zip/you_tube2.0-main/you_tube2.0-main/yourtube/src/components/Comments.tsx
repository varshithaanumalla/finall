import React, { useEffect, useState } from "react";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Textarea } from "./ui/textarea";
import { Button } from "./ui/button";
import { formatDistanceToNow } from "date-fns";
import { useUser } from "@/lib/AuthContext";
import axiosInstance from "@/lib/axiosinstance";
import {
  ThumbsUp,
  ThumbsDown,
  Flag,
  Languages,
  MapPin,
  ChevronDown,
} from "lucide-react";
import { toast } from "sonner";

interface Comment {
  _id: string;
  videoid: string;
  userid: string;
  commentbody: string;
  usercommented: string;
  commentedon: string;
  language?: string;
  location?: string;
  likes?: string[];
  dislikes?: string[];
  isFlagged?: boolean;
  reportCount?: number;
}

const LANGUAGES = [
  { code: "en", name: "English" },
  { code: "hi", name: "Hindi" },
  { code: "es", name: "Spanish" },
  { code: "fr", name: "French" },
  { code: "de", name: "German" },
];

const Comments = ({ videoId }: any) => {
  const [comments, setComments] = useState<Comment[]>([]);
  const [newComment, setNewComment] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [editingCommentId, setEditingCommentId] = useState<string | null>(null);
  const [editText, setEditText] = useState("");
  const [showLocation, setShowLocation] = useState(true);
  const [reportModal, setReportModal] = useState<string | null>(null);
  const [reportReason, setReportReason] = useState("");
  const [translations, setTranslations] = useState<Record<string, string>>({});
  const [translatingId, setTranslatingId] = useState<string | null>(null);
  const [targetLang, setTargetLang] = useState("en");
  const [showLangSelector, setShowLangSelector] = useState<string | null>(null);
  const { user } = useUser();
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadComments();
  }, [videoId]);

  const loadComments = async () => {
    try {
      const res = await axiosInstance.get(`/comment/${videoId}`);
      setComments(res.data);
    } catch (error) {
      console.log(error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div>Loading comments...</div>;
  }

  const handleSubmitComment = async () => {
    if (!user || !newComment.trim()) return;

    setIsSubmitting(true);
    try {
      const res = await axiosInstance.post("/comment/postcomment", {
        videoid: videoId,
        userid: user._id,
        commentbody: newComment,
        usercommented: user.name,
        location: showLocation ? "Unknown" : null,
      });

      if (res.data.comment) {
        if (res.data.flagged) {
          toast.warning(res.data.message || "Comment flagged for review");
        }
        // Reload from the server so comments have their real DB _id (needed
        // for like/dislike/report/translate/edit/delete to work).
        await loadComments();
      }
      setNewComment("");
    } catch (error) {
      console.error("Error adding comment:", error);
      toast.error("Failed to post comment");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleEdit = (comment: Comment) => {
    setEditingCommentId(comment._id);
    setEditText(comment.commentbody);
  };

  const handleUpdateComment = async () => {
    if (!editText.trim()) return;
    try {
      const res = await axiosInstance.post(
        `/comment/editcomment/${editingCommentId}`,
        { commentbody: editText }
      );
      if (res.data) {
        setComments((prev) =>
          prev.map((c) =>
            c._id === editingCommentId ? { ...c, commentbody: editText } : c
          )
        );
        setEditingCommentId(null);
        setEditText("");
        if (res.data.flagged) {
          toast.warning(res.data.message || "Comment flagged for review");
        }
      }
    } catch (error) {
      console.log(error);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      const res = await axiosInstance.delete(`/comment/deletecomment/${id}`);
      if (res.data.comment) {
        setComments((prev) => prev.filter((c) => c._id !== id));
      }
    } catch (error) {
      console.log(error);
    }
  };

  const handleLike = async (id: string) => {
    if (!user) return;
    try {
      const res = await axiosInstance.post(`/comment/like/${id}`, {
        userId: user._id,
      });
      if (res.data) {
        setComments((prev) =>
          prev.map((c) =>
            c._id === id
              ? {
                  ...c,
                  likes: Array(res.data.likeCount).fill(""),
                  dislikes: Array(res.data.dislikeCount).fill(""),
                }
              : c
          )
        );
      }
    } catch (error) {
      console.log(error);
    }
  };

  const handleDislike = async (id: string) => {
    if (!user) return;
    try {
      const res = await axiosInstance.post(`/comment/dislike/${id}`, {
        userId: user._id,
      });
      if (res.data) {
        setComments((prev) =>
          prev.map((c) =>
            c._id === id
              ? {
                  ...c,
                  likes: Array(res.data.likeCount).fill(""),
                  dislikes: Array(res.data.dislikeCount).fill(""),
                }
              : c
          )
        );
      }
    } catch (error) {
      console.log(error);
    }
  };

  const handleTranslate = async (id: string, lang: string) => {
    setTranslatingId(id);
    try {
      const res = await axiosInstance.post(`/comment/translate/${id}`, {
        targetLang: lang,
      });
      if (res.data) {
        setTranslations((prev) => ({ ...prev, [id]: res.data.translated }));
        toast.success(`Translated to ${LANGUAGES.find((l) => l.code === lang)?.name}`);
      }
    } catch (error) {
      console.log(error);
      toast.error("Translation failed");
    } finally {
      setTranslatingId(null);
      setShowLangSelector(null);
    }
  };

  const handleReport = async (id: string) => {
    if (!user || !reportReason.trim()) return;
    try {
      const res = await axiosInstance.post(`/comment/report/${id}`, {
        userId: user._id,
        reason: reportReason,
      });
      if (res.data.reported) {
        toast.success(res.data.message || "Comment reported for review");
        setReportModal(null);
        setReportReason("");
      }
    } catch (error) {
      console.log(error);
      toast.error("Failed to report comment");
    }
  };

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold">{comments.length} Comments</h2>

      {user && (
        <div className="flex gap-4">
          <Avatar className="w-10 h-10">
            <AvatarImage src={user.image || ""} />
            <AvatarFallback>{user.name?.[0] || "U"}</AvatarFallback>
          </Avatar>
          <div className="flex-1 space-y-2">
            <Textarea
              placeholder="Add a comment in any language..."
              value={newComment}
              onChange={(e: any) => setNewComment(e.target.value)}
              className="min-h-[80px] resize-none border-0 border-b-2 rounded-none focus-visible:ring-0"
            />
            <div className="flex items-center justify-between">
              <label className="flex items-center gap-2 text-xs text-gray-500">
                <input
                  type="checkbox"
                  checked={showLocation}
                  onChange={(e) => setShowLocation(e.target.checked)}
                  className="w-3 h-3"
                />
                Show my location
              </label>
              <div className="flex gap-2 justify-end">
                <Button
                  variant="ghost"
                  onClick={() => setNewComment("")}
                  disabled={!newComment.trim()}
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleSubmitComment}
                  disabled={!newComment.trim() || isSubmitting}
                >
                  Comment
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
      <div className="space-y-4">
        {comments.length === 0 ? (
          <p className="text-sm text-gray-500 italic">
            No comments yet. Be the first to comment!
          </p>
        ) : (
          comments.map((comment) => (
            <div key={comment._id} className="flex gap-4">
              <Avatar className="w-10 h-10">
                <AvatarImage src="/placeholder.svg?height=40&width=40" />
                <AvatarFallback>{comment.usercommented[0]}</AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-medium text-sm">
                    {comment.usercommented}
                  </span>
                  <span className="text-xs text-gray-600">
                    {formatDistanceToNow(new Date(comment.commentedon))} ago
                  </span>
                  {comment.location && (
                    <span className="text-xs text-gray-500 flex items-center gap-1">
                      <MapPin className="w-3 h-3" />
                      {comment.location}
                    </span>
                  )}
                  {comment.language && comment.language !== "en" && (
                    <span className="text-xs bg-gray-100 dark:bg-gray-800 px-1.5 py-0.5 rounded">
                      {LANGUAGES.find((l) => l.code === comment.language)?.name || comment.language}
                    </span>
                  )}
                </div>

                {editingCommentId === comment._id ? (
                  <div className="space-y-2">
                    <Textarea
                      value={editText}
                      onChange={(e) => setEditText(e.target.value)}
                    />
                    <div className="flex gap-2 justify-end">
                      <Button
                        onClick={handleUpdateComment}
                        disabled={!editText.trim()}
                      >
                        Save
                      </Button>
                      <Button
                        variant="ghost"
                        onClick={() => {
                          setEditingCommentId(null);
                          setEditText("");
                        }}
                      >
                        Cancel
                      </Button>
                    </div>
                  </div>
                ) : (
                  <>
                    <p className="text-sm">
                      {translations[comment._id] || comment.commentbody}
                    </p>
                    {translations[comment._id] && (
                      <button
                        onClick={() => {
                          setTranslations((prev) => {
                            const copy = { ...prev };
                            delete copy[comment._id];
                            return copy;
                          });
                        }}
                        className="text-xs text-blue-600 hover:underline mt-1"
                      >
                        Show original
                      </button>
                    )}

                    <div className="flex items-center gap-4 mt-2 text-sm text-gray-500">
                      <button
                        onClick={() => handleLike(comment._id)}
                        className="flex items-center gap-1 hover:text-blue-600"
                      >
                        <ThumbsUp className="w-4 h-4" />
                        {comment.likes?.length || 0}
                      </button>
                      <button
                        onClick={() => handleDislike(comment._id)}
                        className="flex items-center gap-1 hover:text-blue-600"
                      >
                        <ThumbsDown className="w-4 h-4" />
                        {comment.dislikes?.length || 0}
                      </button>

                      {/* Translate dropdown */}
                      <div className="relative">
                        <button
                          onClick={() =>
                            setShowLangSelector(
                              showLangSelector === comment._id ? null : comment._id
                            )
                          }
                          className="flex items-center gap-1 hover:text-blue-600"
                        >
                          <Languages className="w-4 h-4" />
                          Translate
                        </button>
                        {showLangSelector === comment._id && (
                          <div className="absolute top-full left-0 mt-1 bg-white dark:bg-gray-800 border rounded-lg shadow-lg z-10 min-w-32">
                            {LANGUAGES.map((lang) => (
                              <button
                                key={lang.code}
                                onClick={() => handleTranslate(comment._id, lang.code)}
                                className="block w-full text-left px-3 py-1.5 text-sm hover:bg-gray-100 dark:hover:bg-gray-700"
                              >
                                {lang.name}
                              </button>
                            ))}
                          </div>
                        )}
                        {translatingId === comment._id && (
                          <span className="text-xs ml-2">Translating...</span>
                        )}
                      </div>

                      <button
                        onClick={() => setReportModal(comment._id)}
                        className="flex items-center gap-1 hover:text-red-600"
                      >
                        <Flag className="w-4 h-4" />
                        Report
                      </button>

                      {comment.userid === user?._id && (
                        <div className="flex gap-2">
                          <button onClick={() => handleEdit(comment)}>
                            Edit
                          </button>
                          <button onClick={() => handleDelete(comment._id)}>
                            Delete
                          </button>
                        </div>
                      )}
                    </div>

                    {comment.isFlagged && (
                      <p className="text-xs text-orange-600 mt-1">
                        ⚠ This comment has been flagged for review
                      </p>
                    )}
                  </>
                )}
              </div>
            </div>
          ))
        )}
      </div>

      {/* Report modal */}
      {reportModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white dark:bg-gray-900 p-6 rounded-lg shadow-xl max-w-md w-full mx-4">
            <h3 className="text-lg font-medium mb-4">Report Comment</h3>
            <p className="text-sm text-gray-500 mb-2">
              Please provide a reason for reporting this comment. Our moderators will review it.
            </p>
            <Textarea
              value={reportReason}
              onChange={(e) => setReportReason(e.target.value)}
              placeholder="Reason for reporting..."
              className="mb-4"
              rows={3}
            />
            <div className="flex justify-end gap-2">
              <Button
                variant="ghost"
                onClick={() => {
                  setReportModal(null);
                  setReportReason("");
                }}
              >
                Cancel
              </Button>
              <Button
                onClick={() => handleReport(reportModal)}
                disabled={!reportReason.trim()}
                className="bg-red-600 hover:bg-red-700"
              >
                Submit Report
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Comments;
