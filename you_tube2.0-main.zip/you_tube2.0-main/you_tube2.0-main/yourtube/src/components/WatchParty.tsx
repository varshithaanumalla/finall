"use client";

import { useState, useEffect, useRef } from "react";
import { io, Socket } from "socket.io-client";
import {
  Mic,
  MicOff,
  Video,
  VideoOff,
  Phone,
  ScreenShare,
  Users,
  Send,
  Copy,
  Plus,
  Maximize2,
  X,
} from "lucide-react";
import { useUser } from "@/lib/AuthContext";
import axiosInstance from "@/lib/axiosinstance";
import { toast } from "sonner";

interface WatchPartyProps {
  videoId: string;
  videoTitle: string;
}

interface Participant {
  userId: string;
  name: string;
  image: string;
  muted: boolean;
  cameraOff: boolean;
}

interface ChatMessage {
  name: string;
  text: string;
  sender: string;
}

export default function WatchParty({ videoId, videoTitle }: WatchPartyProps) {
  const { user } = useUser();
  const [socket, setSocket] = useState<Socket | null>(null);
  const [roomId, setRoomId] = useState<string | null>(null);
  const [participants, setParticipants] = useState<Participant[]>([]);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [chatInput, setChatInput] = useState("");
  const [muted, setMuted] = useState(false);
  const [cameraOff, setCameraOff] = useState(false);
  const [isSharing, setIsSharing] = useState(false);
  const [showPartyPanel, setShowPartyPanel] = useState(false);
  const [showParticipants, setShowParticipants] = useState(false);
  // Remote participants' media streams, keyed by their socket id.
  const [remoteStreams, setRemoteStreams] = useState<Record<string, MediaStream>>({});
  // Spotlight: when set, show this stream large (Zoom-like). "local" or a peerId.
  const [spotlight, setSpotlight] = useState<string | null>(null);

  const localVideoRef = useRef<HTMLVideoElement>(null);
  const localStreamRef = useRef<MediaStream | null>(null);
  const screenStreamRef = useRef<MediaStream | null>(null);
  const peerConnections = useRef<Map<string, RTCPeerConnection>>(new Map());
  const socketRef = useRef<Socket | null>(null);
  // Perfect-negotiation bookkeeping, keyed by peer socket id.
  const makingOffer = useRef<Record<string, boolean>>({});
  const politeRef = useRef<Record<string, boolean>>({});
  const pendingCandidates = useRef<Record<string, RTCIceCandidateInit[]>>({});
  // The video RTCRtpSender per peer, so we can replaceTrack for screen share.
  const videoSenders = useRef<Map<string, RTCRtpSender>>(new Map());

  const BACKEND_URL = process.env.BACKEND_URL || "http://localhost:5000";

  // WebRTC config (using Google's public STUN server)
  const rtcConfig: RTCConfiguration = {
    iceServers: [{ urls: "stun:stun.l.google.com:19302" }],
  };

  // Create a new watch party
  const createParty = async () => {
    if (!user) {
      toast.error("Please log in to start a watch party");
      return;
    }
    try {
      const res = await axiosInstance.post("/watchparty/create", { videoId });
      const party = res.data.party;
      setRoomId(party.roomId);
      setParticipants(party.participants);
      setShowPartyPanel(true);
      // Acquire camera/mic BEFORE connecting the socket so the first WebRTC
      // offer already carries our media tracks.
      await startMedia();
      connectSocket(party.roomId);
      loadMessages(party.roomId);
      toast.success("Watch party created! Share the room ID with friends.");
    } catch (error) {
      console.error("Create party error:", error);
      toast.error("Failed to create watch party");
    }
  };

  // Join an existing watch party
  const joinParty = async (joinRoomId: string) => {
    if (!user) {
      toast.error("Please log in to join a watch party");
      return;
    }
    if (!joinRoomId) {
      toast.error("Please enter a room ID");
      return;
    }
    try {
      const res = await axiosInstance.post(`/watchparty/join/${joinRoomId}`);
      const party = res.data.party;
      setRoomId(party.roomId);
      setParticipants(party.participants);
      setShowPartyPanel(true);
      // Acquire camera/mic BEFORE connecting the socket so our tracks are
      // ready when we answer the host's WebRTC offer.
      await startMedia();
      connectSocket(party.roomId);
      loadMessages(party.roomId);
      toast.success("Joined watch party!");
    } catch (error) {
      console.error("Join party error:", error);
      toast.error("Failed to join watch party. Check the room ID.");
    }
  };

  // Load persisted chat history for a room.
  const loadMessages = async (room: string) => {
    try {
      const res = await axiosInstance.get(`/watchparty/messages/${room}`);
      const msgs = (res.data?.messages || []).map((m: any) => ({
        name: m.name,
        text: m.text,
        sender: m.userId,
      }));
      setMessages(msgs);
    } catch (err) {
      console.error("Load messages error:", err);
    }
  };

  // Start local media (camera + mic)
  const startMedia = async () => {
    try {
      if (!navigator.mediaDevices?.getUserMedia) {
        toast.error("Camera API unavailable (needs HTTPS or localhost)");
        return;
      }
      const stream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: true,
      });
      localStreamRef.current = stream;
      if (localVideoRef.current) {
        localVideoRef.current.srcObject = stream;
        localVideoRef.current.play?.().catch(() => {});
      }
    } catch (error: any) {
      console.error("Media access error:", error);
      toast.error(`Camera/mic error: ${error?.name || "denied"}`);
    }
  };

  // Connect Socket.IO
  const connectSocket = (room: string) => {
    const s = io(BACKEND_URL, { transports: ["websocket"] });
    setSocket(s);
    socketRef.current = s;

    s.on("connect", () => {
      s.emit("join-party", room);
    });

    // A new peer joined. The EXISTING member is the "impolite" peer and
    // initiates the connection. Just creating the peer (which adds local
    // tracks) fires onnegotiationneeded, which sends the offer. We must NOT
    // also create a manual offer here or the two offers collide and no media
    // ends up flowing.
    s.on("user-joined", ({ socketId }) => {
      if (!socketId) return;
      getOrCreatePeer(socketId, s, room, /* polite */ false);
    });

    s.on("offer", async ({ offer, sender }) => {
      const peerId = sender;
      const pc = getOrCreatePeer(peerId, s, room, /* polite */ true);

      const offerCollision =
        makingOffer.current[peerId] || pc.signalingState !== "stable";
      const ignoreOffer = !politeRef.current[peerId] && offerCollision;
      if (ignoreOffer) return;

      try {
        if (offerCollision) {
          // Polite peer rolls back its own offer to accept the incoming one.
          await Promise.all([
            pc.setLocalDescription({ type: "rollback" } as any).catch(() => {}),
            pc.setRemoteDescription(new RTCSessionDescription(offer)),
          ]);
        } else {
          await pc.setRemoteDescription(new RTCSessionDescription(offer));
        }
        await drainCandidates(peerId, pc);
        await pc.setLocalDescription(await pc.createAnswer());
        s.emit("answer", { roomId: room, target: peerId, answer: pc.localDescription });
      } catch (err) {
        console.error("handle offer error", err);
      }
    });

    s.on("answer", async ({ answer, sender }) => {
      const pc = peerConnections.current.get(sender);
      if (pc) {
        await pc.setRemoteDescription(new RTCSessionDescription(answer));
        await drainCandidates(sender, pc);
      }
    });

    s.on("ice-candidate", async ({ candidate, sender }) => {
      const pc = peerConnections.current.get(sender);
      if (!candidate) return;
      if (pc && pc.remoteDescription && pc.remoteDescription.type) {
        try {
          await pc.addIceCandidate(new RTCIceCandidate(candidate));
        } catch (err) {
          console.error("addIceCandidate error", err);
        }
      } else {
        // Queue until remote description is set.
        pendingCandidates.current[sender] = pendingCandidates.current[sender] || [];
        pendingCandidates.current[sender].push(candidate);
      }
    });

    s.on("party-message", ({ name, text, sender }) => {
      setMessages((prev) => [...prev, { name, text, sender }]);
    });

    s.on("user-left", ({ socketId }) => {
      const peerId = socketId;
      const pc = peerConnections.current.get(peerId);
      if (pc) {
        pc.close();
        peerConnections.current.delete(peerId);
      }
      videoSenders.current.delete(peerId);
      setRemoteStreams((prev) => {
        const next = { ...prev };
        delete next[peerId];
        return next;
      });
    });

    s.on("toggle-mute", ({ sender, muted }) => {
      setParticipants((prev) =>
        prev.map((p) => (p.userId === sender ? { ...p, muted } : p))
      );
    });

    s.on("toggle-camera", ({ sender, cameraOff }) => {
      setParticipants((prev) =>
        prev.map((p) => (p.userId === sender ? { ...p, cameraOff } : p))
      );
    });
  };

  // Apply any ICE candidates that arrived before the remote description.
  const drainCandidates = async (peerId: string, pc: RTCPeerConnection) => {
    const queued = pendingCandidates.current[peerId];
    if (queued && queued.length) {
      for (const c of queued) {
        try {
          await pc.addIceCandidate(new RTCIceCandidate(c));
        } catch (err) {
          console.error("drain addIceCandidate error", err);
        }
      }
      pendingCandidates.current[peerId] = [];
    }
  };

  // Create (or fetch) a peer connection for a given peer, wiring all handlers
  // using the perfect-negotiation pattern so renegotiation (e.g. screen share)
  // works reliably.
  const getOrCreatePeer = (
    peerId: string,
    s: Socket,
    room: string,
    polite: boolean
  ): RTCPeerConnection => {
    const existing = peerConnections.current.get(peerId);
    if (existing) return existing;

    const pc = new RTCPeerConnection(rtcConfig);
    politeRef.current[peerId] = polite;

    // Add current local tracks and remember the video sender for screen share.
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach((track) => {
        const sender = pc.addTrack(track, localStreamRef.current!);
        if (track.kind === "video") videoSenders.current.set(peerId, sender);
      });
    }

    pc.onicecandidate = (event) => {
      if (event.candidate) {
        s.emit("ice-candidate", {
          roomId: room,
          target: peerId,
          candidate: event.candidate,
        });
      }
    };

    pc.ontrack = (event) => {
      // Accumulate the peer's tracks. We rebuild a NEW MediaStream on each
      // track (new object reference) so React re-renders and the <video>
      // element re-binds with BOTH audio and video tracks. Mutating the same
      // stream object in place would not re-trigger the consumer effect, so a
      // late-arriving audio track could be missed.
      const pc2 = peerConnections.current.get(peerId);
      const tracks = pc2
        ? pc2.getReceivers().map((r) => r.track).filter(Boolean)
        : [event.track];
      const fresh = new MediaStream(tracks as MediaStreamTrack[]);
      setRemoteStreams((prev) => ({ ...prev, [peerId]: fresh }));
    };

    // Renegotiate automatically when tracks are added/replaced (screen share).
    pc.onnegotiationneeded = async () => {
      try {
        makingOffer.current[peerId] = true;
        await pc.setLocalDescription(await pc.createOffer());
        s.emit("offer", { roomId: room, target: peerId, offer: pc.localDescription });
      } catch (err) {
        console.error("negotiationneeded error", err);
      } finally {
        makingOffer.current[peerId] = false;
      }
    };

    peerConnections.current.set(peerId, pc);
    return pc;
  };

  // Toggle mute
  const toggleMute = () => {
    const newMuted = !muted;
    if (localStreamRef.current) {
      localStreamRef.current.getAudioTracks().forEach((track) => {
        track.enabled = !newMuted; // enabled when NOT muted
      });
    }
    setMuted(newMuted);
    socket?.emit("toggle-mute", { roomId, muted: newMuted });
  };

  // Toggle camera
  const toggleCamera = () => {
    const newCameraOff = !cameraOff;
    if (localStreamRef.current) {
      localStreamRef.current.getVideoTracks().forEach((track) => {
        track.enabled = !newCameraOff; // enabled when camera is ON
      });
    }
    setCameraOff(newCameraOff);
    socket?.emit("toggle-camera", { roomId, cameraOff: newCameraOff });
  };

  // Toggle screen share
  const toggleScreenShare = async () => {
    if (!isSharing) {
      try {
        const screenStream = await navigator.mediaDevices.getDisplayMedia({
          video: true,
        });
        screenStreamRef.current = screenStream;
        const screenTrack = screenStream.getVideoTracks()[0];

        // Show the screen in our own local preview.
        if (localVideoRef.current) {
          localVideoRef.current.srcObject = screenStream;
        }

        // Replace the outgoing video track for every peer (seamless, no
        // renegotiation needed since kind/count are unchanged).
        videoSenders.current.forEach((sender) => {
          sender.replaceTrack(screenTrack).catch((e) =>
            console.error("replaceTrack (screen) error", e)
          );
        });

        // Let other participants know we started sharing.
        socketRef.current?.emit("screen-share-start", { roomId });

        // When the user stops sharing (via browser UI or our button), revert.
        screenTrack.onended = () => stopScreenShare();

        setIsSharing(true);
        toast.success("Screen sharing started");
      } catch (error) {
        console.error("Screen share error:", error);
        toast.error("Could not start screen sharing");
      }
    } else {
      stopScreenShare();
    }
  };

  // Stop screen sharing and revert to the camera.
  const stopScreenShare = () => {
    const cameraTrack = localStreamRef.current?.getVideoTracks()[0] || null;

    // Revert the outgoing track for all peers.
    if (cameraTrack) {
      videoSenders.current.forEach((sender) => {
        sender.replaceTrack(cameraTrack).catch((e) =>
          console.error("replaceTrack (camera) error", e)
        );
      });
    }

    // Revert our own preview back to the camera stream.
    if (localVideoRef.current && localStreamRef.current) {
      localVideoRef.current.srcObject = localStreamRef.current;
    }

    // Stop the screen capture tracks.
    if (screenStreamRef.current) {
      screenStreamRef.current.getTracks().forEach((t) => t.stop());
      screenStreamRef.current = null;
    }

    socketRef.current?.emit("screen-share-stop", { roomId });
    setIsSharing(false);
    toast.info("Screen sharing stopped");
  };

  // Send chat message
  const sendMessage = () => {
    if (!chatInput.trim() || !socket || !roomId || !user) return;
    const text = chatInput;
    socket.emit("party-message", {
      roomId,
      name: user.name,
      text,
    });
    setMessages((prev) => [...prev, { name: user.name, text, sender: "me" }]);
    setChatInput("");
    // Persist so late joiners / reloads keep history (fire-and-forget).
    axiosInstance
      .post(`/watchparty/message/${roomId}`, { text })
      .catch((err) => console.error("Persist message error:", err));
  };

  // Leave party
  const leaveParty = async () => {
    if (roomId) {
      try {
        await axiosInstance.post(`/watchparty/leave/${roomId}`);
      } catch (error) {
        console.error("Leave error:", error);
      }
    }
    // Stop media
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach((track) => track.stop());
    }
    // Close peer connections
    peerConnections.current.forEach((pc) => pc.close());
    peerConnections.current.clear();
    // Disconnect socket
    socket?.disconnect();
    setSocket(null);
    setRoomId(null);
    setShowPartyPanel(false);
    setParticipants([]);
    setMessages([]);
    toast.info("Left watch party");
  };

  // Copy room ID
  const copyRoomId = () => {
    if (roomId) {
      navigator.clipboard.writeText(roomId);
      toast.success("Room ID copied to clipboard");
    }
  };

  // Bind the local camera stream to the preview element once the party panel
  // has actually rendered (the <video> ref is null while the panel is hidden,
  // so assigning srcObject inside startMedia can silently no-op).
  useEffect(() => {
    if (showPartyPanel && localVideoRef.current && localStreamRef.current) {
      localVideoRef.current.srcObject = localStreamRef.current;
      localVideoRef.current.play?.().catch(() => {});
    }
  }, [showPartyPanel]);

  useEffect(() => {
    return () => {
      if (localStreamRef.current) {
        localStreamRef.current.getTracks().forEach((track) => track.stop());
      }
      socket?.disconnect();
      peerConnections.current.forEach((pc) => pc.close());
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (!showPartyPanel) {
    return (
      <div className="flex flex-col gap-2">
        <div className="flex gap-2">
          <button
            onClick={createParty}
            title={user ? "Start a watch party" : "Log in to start a watch party"}
            className="flex items-center gap-2 bg-red-600 text-white px-4 py-2 rounded-full hover:bg-red-700 transition-colors text-sm disabled:opacity-60"
          >
            <Users className="w-4 h-4" />
            Start Watch Party
          </button>
          <JoinPartyDialog onJoin={joinParty} disabled={!user} />
        </div>
        {!user && (
          <p className="text-xs text-gray-500 dark:text-gray-400">
            Please log in to start or join a watch party.
          </p>
        )}
      </div>
    );
  }

  return (
    <div className="fixed bottom-0 right-0 w-96 bg-white dark:bg-gray-900 border-l border-t rounded-tl-lg shadow-2xl z-50">
      {/* Header */}
      <div className="flex items-center justify-between p-3 border-b bg-gray-50 dark:bg-gray-800 rounded-tl-lg">
        <div className="flex items-center gap-2">
          <Users className="w-5 h-5" />
          <span className="font-medium text-sm">Watch Party</span>
          <span className="text-xs text-gray-500">{participants.length} watching</span>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={copyRoomId}
            className="text-xs flex items-center gap-1 text-blue-600 hover:underline"
          >
            <Copy className="w-3 h-3" />
            {roomId?.slice(0, 12)}...
          </button>
          <button
            onClick={() => setShowParticipants(!showParticipants)}
            className="p-1 hover:bg-gray-200 dark:hover:bg-gray-700 rounded"
          >
            <Users className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Local video preview */}
      <div className="p-2">
        <div
          className="relative bg-black rounded-lg overflow-hidden aspect-video cursor-pointer group/tile"
          onClick={() => setSpotlight("local")}
          title="Click to expand"
        >
          <video
            ref={localVideoRef}
            autoPlay
            muted
            playsInline
            className={`w-full h-full ${cameraOff ? "hidden" : ""}`}
          />
          {cameraOff && (
            <div className="absolute inset-0 flex items-center justify-center bg-gray-800">
              <VideoOff className="w-8 h-8 text-gray-400" />
            </div>
          )}
          <div className="absolute bottom-1 left-1 text-xs text-white bg-black/50 px-1 rounded">
            You {muted && "(muted)"} {isSharing && "(sharing screen)"}
          </div>
          <div className="absolute top-1 right-1 opacity-0 group-hover/tile:opacity-100 transition-opacity">
            <Maximize2 className="w-4 h-4 text-white drop-shadow" />
          </div>
        </div>
      </div>

      {/* Remote participant videos */}
      {Object.keys(remoteStreams).length > 0 && (
        <div className="px-2 pb-2 grid grid-cols-2 gap-2">
          {Object.entries(remoteStreams).map(([peerId, stream]) => (
            <RemoteVideo
              key={peerId}
              stream={stream}
              onExpand={() => setSpotlight(peerId)}
            />
          ))}
        </div>
      )}

      {/* Participants list */}
      {showParticipants && (
        <div className="px-3 pb-2 max-h-32 overflow-y-auto">
          <p className="text-xs font-medium mb-1">Participants</p>
          {participants.map((p) => (
            <div key={p.userId} className="flex items-center gap-2 py-1 text-sm">
              <div className="w-6 h-6 rounded-full bg-gray-300 flex items-center justify-center text-xs">
                {p.name?.[0]}
              </div>
              <span>{p.name}</span>
              {p.muted && <MicOff className="w-3 h-3 text-gray-400" />}
              {p.cameraOff && <VideoOff className="w-3 h-3 text-gray-400" />}
            </div>
          ))}
        </div>
      )}

      {/* Chat */}
      <div className="px-3 flex-1">
        <div className="max-h-40 overflow-y-auto space-y-1 mb-2">
          {messages.map((msg, i) => (
            <div key={i} className="text-sm">
              <span className="font-medium text-blue-600">{msg.name}:</span>{" "}
              <span>{msg.text}</span>
            </div>
          ))}
          {messages.length === 0 && (
            <p className="text-xs text-gray-400 italic">Start chatting...</p>
          )}
        </div>
        <div className="flex gap-1 mb-2">
          <input
            type="text"
            value={chatInput}
            onChange={(e) => setChatInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && sendMessage()}
            placeholder="Type a message..."
            className="flex-1 text-sm px-2 py-1 border rounded dark:bg-gray-800 dark:border-gray-700"
          />
          <button
            onClick={sendMessage}
            className="p-1 bg-blue-600 text-white rounded hover:bg-blue-700"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Controls */}
      <div className="flex items-center justify-center gap-3 p-3 border-t bg-gray-50 dark:bg-gray-800 rounded-tl-lg">
        <button
          onClick={toggleMute}
          className={`p-2 rounded-full ${muted ? "bg-red-600 text-white" : "bg-gray-200 dark:bg-gray-700"}`}
          title={muted ? "Unmute" : "Mute"}
        >
          {muted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
        </button>
        <button
          onClick={toggleCamera}
          className={`p-2 rounded-full ${cameraOff ? "bg-red-600 text-white" : "bg-gray-200 dark:bg-gray-700"}`}
          title={cameraOff ? "Camera On" : "Camera Off"}
        >
          {cameraOff ? <VideoOff className="w-5 h-5" /> : <Video className="w-5 h-5" />}
        </button>
        <button
          onClick={toggleScreenShare}
          className={`p-2 rounded-full ${isSharing ? "bg-green-600 text-white" : "bg-gray-200 dark:bg-gray-700"}`}
          title="Screen Share"
        >
          <ScreenShare className="w-5 h-5" />
        </button>
        <button
          onClick={leaveParty}
          className="p-2 rounded-full bg-red-600 text-white hover:bg-red-700"
          title="Leave"
        >
          <Phone className="w-5 h-5 rotate-[135deg]" />
        </button>
      </div>

      {/* Spotlight (Zoom-like full-window view of a selected tile) */}
      {spotlight && (
        <SpotlightOverlay
          label={spotlight === "local" ? "You" : "Participant"}
          stream={
            spotlight === "local"
              ? localStreamRef.current
              : remoteStreams[spotlight] || null
          }
          muted={spotlight === "local"}
          onClose={() => setSpotlight(null)}
        />
      )}
    </div>
  );
}

// Join party dialog component
function JoinPartyDialog({
  onJoin,
  disabled = false,
}: {
  onJoin: (roomId: string) => void;
  disabled?: boolean;
}) {
  const [show, setShow] = useState(false);
  const [roomId, setRoomId] = useState("");

  return (
    <>
      <button
        onClick={() => {
          if (disabled) {
            toast.error("Please log in to join a watch party");
            return;
          }
          setShow(true);
        }}
        title={disabled ? "Log in to join a watch party" : "Join a watch party"}
        className="flex items-center gap-2 bg-gray-100 dark:bg-gray-800 px-4 py-2 rounded-full hover:bg-gray-200 transition-colors text-sm disabled:opacity-60"
      >
        <Plus className="w-4 h-4" />
        Join Party
      </button>
      {show && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white dark:bg-gray-900 p-6 rounded-lg shadow-xl">
            <h3 className="text-lg font-medium mb-4">Join Watch Party</h3>
            <input
              type="text"
              value={roomId}
              onChange={(e) => setRoomId(e.target.value)}
              placeholder="Enter Room ID"
              className="block w-64 px-3 py-2 border rounded mb-4 dark:bg-gray-800 dark:border-gray-700"
            />
            <div className="flex justify-end gap-2">
              <button
                onClick={() => setShow(false)}
                className="px-4 py-2 text-sm rounded hover:bg-gray-100 dark:hover:bg-gray-800"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  if (roomId.trim()) {
                    onJoin(roomId.trim());
                    setShow(false);
                  }
                }}
                className="px-4 py-2 bg-blue-600 text-white rounded text-sm hover:bg-blue-700"
              >
                Join
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}


// Renders a single remote participant's media stream.
function RemoteVideo({
  stream,
  onExpand,
}: {
  stream: MediaStream;
  onExpand?: () => void;
}) {
  const ref = useRef<HTMLVideoElement>(null);
  const [needsUnmute, setNeedsUnmute] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    el.srcObject = stream;
    // Try to play WITH audio first. If the browser blocks autoplay-with-sound,
    // fall back to muted playback and surface an "unmute" button so a user
    // gesture can enable audio.
    const tryPlay = () => {
      el.muted = false;
      el.play()
        .then(() => setNeedsUnmute(false))
        .catch(() => {
          el.muted = true;
          setNeedsUnmute(true);
          el.play().catch(() => {});
        });
    };
    tryPlay();
    el.onloadedmetadata = tryPlay;
    return () => {
      el.onloadedmetadata = null;
    };
  }, [stream]);

  const enableAudio = (e: React.MouseEvent) => {
    e.stopPropagation();
    const el = ref.current;
    if (!el) return;
    el.muted = false;
    el.play()
      .then(() => setNeedsUnmute(false))
      .catch(() => {});
  };

  return (
    <div
      className="relative bg-black rounded-lg overflow-hidden aspect-video cursor-pointer group/tile"
      onClick={onExpand}
      title="Click to expand"
    >
      <video
        ref={ref}
        autoPlay
        playsInline
        className="w-full h-full object-cover"
      />
      {needsUnmute && (
        <button
          onClick={enableAudio}
          className="absolute bottom-1 left-1 bg-red-600 text-white text-[10px] px-2 py-0.5 rounded-full hover:bg-red-700"
          title="Click to hear audio"
        >
          🔊 Unmute
        </button>
      )}
      <div className="absolute top-1 right-1 opacity-0 group-hover/tile:opacity-100 transition-opacity">
        <Maximize2 className="w-4 h-4 text-white drop-shadow" />
      </div>
    </div>
  );
}

// Full-window spotlight view of a single stream (Zoom-like).
function SpotlightOverlay({
  stream,
  label,
  muted,
  onClose,
}: {
  stream: MediaStream | null;
  label: string;
  muted: boolean;
  onClose: () => void;
}) {
  const ref = useRef<HTMLVideoElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el || !stream) return;
    el.srcObject = stream;
    const tryPlay = () => {
      el.play().catch(() => {
        el.muted = true;
        el.play().catch(() => {});
      });
    };
    tryPlay();
    el.onloadedmetadata = tryPlay;
    return () => {
      el.onloadedmetadata = null;
    };
  }, [stream]);

  // Close on Escape key.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  return (
    <div
      className="fixed inset-0 z-[60] bg-black/95 flex items-center justify-center"
      onClick={onClose}
    >
      <video
        ref={ref}
        autoPlay
        playsInline
        muted={muted}
        className="w-screen h-screen object-contain"
        onClick={(e) => e.stopPropagation()}
      />
      <div className="absolute top-4 left-4 bg-black/60 text-white px-3 py-1 rounded text-sm">
        {label} — click background or press Esc to close
      </div>
      <button
        onClick={onClose}
        className="absolute top-4 right-4 bg-white/10 hover:bg-white/20 text-white rounded-full p-2"
        title="Close (Esc)"
      >
        <X className="w-6 h-6" />
      </button>
    </div>
  );
}
