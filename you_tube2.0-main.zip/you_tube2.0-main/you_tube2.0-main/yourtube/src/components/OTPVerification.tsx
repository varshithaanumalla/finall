"use client";

import { useState } from "react";
import { Shield, Mail } from "lucide-react";
import { useUser } from "@/lib/AuthContext";
import axiosInstance from "@/lib/axiosinstance";
import { toast } from "sonner";
import { Button } from "./ui/button";
import { Input } from "./ui/input";

export default function OTPVerification({
  email,
  previewUrl,
  emailPreview,
  onSuccess,
  onCancel,
}: {
  email: string;
  previewUrl?: string | null;
  emailPreview?: { from: string; subject: string; html: string } | null;
  onSuccess: (data: any) => void;
  onCancel: () => void;
}) {
  const [otp, setOtp] = useState("");
  const [loading, setLoading] = useState(false);
  const [inboxOpen, setInboxOpen] = useState(false);

  const handleVerify = async () => {
    if (!otp.trim()) return;
    setLoading(true);
    try {
      const res = await axiosInstance.post("/user/verify-otp", {
        email,
        otp,
      });
      if (res.data.token) {
        toast.success("Login successful!");
        onSuccess(res.data);
      }
    } catch (error: any) {
      const msg = error.response?.data?.message || "OTP verification failed";
      toast.error(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white dark:bg-gray-900 p-6 rounded-lg shadow-xl max-w-sm w-full mx-4">
        <div className="flex items-center gap-2 mb-4">
          <Shield className="w-6 h-6 text-blue-600" />
          <h3 className="text-lg font-semibold">Verify Your Identity</h3>
        </div>
        <div className="flex items-center gap-2 text-sm text-gray-500 mb-4">
          <Mail className="w-4 h-4" />
          <p>A verification email with your OTP was sent to {email}</p>
        </div>

        {/* In-app inbox: open the actual sent email to read the OTP (zero setup). */}
        {emailPreview && (
          <div className="mb-4">
            {!inboxOpen ? (
              <button
                onClick={() => setInboxOpen(true)}
                className="w-full flex items-center gap-2 rounded-md border border-blue-300 bg-blue-50 dark:bg-blue-950/40 dark:border-blue-700 p-3 text-sm hover:bg-blue-100 dark:hover:bg-blue-900/50"
              >
                <Mail className="w-4 h-4 text-blue-600" />
                <span className="font-medium text-blue-800 dark:text-blue-300">
                  📩 Open verification email (click to read your OTP)
                </span>
              </button>
            ) : (
              <div className="rounded-md border dark:border-gray-700 overflow-hidden">
                <div className="bg-gray-100 dark:bg-gray-800 px-3 py-2 text-xs">
                  <div><span className="text-gray-500">From:</span> {emailPreview.from}</div>
                  <div><span className="text-gray-500">To:</span> {email}</div>
                  <div><span className="text-gray-500">Subject:</span> {emailPreview.subject}</div>
                </div>
                <div
                  className="p-2 bg-white dark:bg-gray-900 max-h-64 overflow-auto"
                  dangerouslySetInnerHTML={{ __html: emailPreview.html }}
                />
              </div>
            )}
          </div>
        )}

        {previewUrl && (
          <div className="mb-4 text-xs text-gray-500">
            Real email also sent —{" "}
            <a
              href={previewUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="text-blue-600 dark:text-blue-400 underline"
            >
              open in email viewer
            </a>
          </div>
        )}
        <Input
          type="text"
          value={otp}
          onChange={(e) => setOtp(e.target.value)}
          placeholder="Enter 6-digit OTP"
          maxLength={6}
          className="text-center text-2xl tracking-widest mb-4"
          onKeyDown={(e) => e.key === "Enter" && handleVerify()}
        />
        <div className="flex justify-end gap-2">
          <Button variant="ghost" onClick={onCancel}>
            Cancel
          </Button>
          <Button onClick={handleVerify} disabled={!otp.trim() || loading}>
            {loading ? "Verifying..." : "Verify OTP"}
          </Button>
        </div>
      </div>
    </div>
  );
}
