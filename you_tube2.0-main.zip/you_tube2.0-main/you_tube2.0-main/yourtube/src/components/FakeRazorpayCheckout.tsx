"use client";

import { useState } from "react";
import { X, Lock, CreditCard } from "lucide-react";

interface FakeRazorpayProps {
  amount: number; // in paise
  planName: string;
  email?: string;
  name?: string;
  onSuccess: () => void;
  onDismiss: () => void;
}

// A visual simulation of the Razorpay checkout popup for demo mode (no real
// keys / account needed). Mirrors the real checkout layout and test-card flow.
export default function FakeRazorpayCheckout({
  amount,
  planName,
  email,
  name,
  onSuccess,
  onDismiss,
}: FakeRazorpayProps) {
  const [card, setCard] = useState("");
  const [expiry, setExpiry] = useState("");
  const [cvv, setCvv] = useState("");
  const [paying, setPaying] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const rupees = (amount / 100).toLocaleString("en-IN");

  const fillTestCard = () => {
    setCard("4111 1111 1111 1111");
    setExpiry("12/34");
    setCvv("123");
    setError(null);
  };

  const handlePay = () => {
    const digits = card.replace(/\s/g, "");
    if (digits.length < 16 || !expiry || cvv.length < 3) {
      setError("Enter valid card details (or click “Use test card”).");
      return;
    }
    setError(null);
    setPaying(true);
    // Simulate network/processing latency like the real gateway.
    setTimeout(() => {
      setPaying(false);
      onSuccess();
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-[70] bg-black/60 flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-white dark:bg-gray-900 rounded-xl overflow-hidden shadow-2xl">
        {/* Header (Razorpay-style blue bar) */}
        <div className="bg-[#0c2451] text-white p-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-[#3395ff] rounded px-2 py-1 text-sm font-bold">
              Razorpay
            </div>
            <span className="text-xs opacity-80">Test Mode</span>
          </div>
          <button onClick={onDismiss} className="hover:opacity-70">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Merchant + amount */}
        <div className="p-4 border-b dark:border-gray-800">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-semibold">YourTube Premium</p>
              <p className="text-xs text-gray-500">{planName} Plan Subscription</p>
            </div>
            <div className="text-right">
              <p className="text-xs text-gray-500">Amount</p>
              <p className="text-lg font-bold">₹{rupees}</p>
            </div>
          </div>
          {(email || name) && (
            <p className="text-xs text-gray-500 mt-2">
              {name} {email ? `• ${email}` : ""}
            </p>
          )}
        </div>

        {/* Card form */}
        <div className="p-4 space-y-3">
          <div className="flex items-center gap-2 text-sm font-medium">
            <CreditCard className="w-4 h-4" /> Card Details
          </div>

          <input
            value={card}
            onChange={(e) => setCard(e.target.value)}
            placeholder="Card Number"
            inputMode="numeric"
            className="w-full px-3 py-2 border rounded dark:bg-gray-800 dark:border-gray-700 text-sm"
          />
          <div className="flex gap-3">
            <input
              value={expiry}
              onChange={(e) => setExpiry(e.target.value)}
              placeholder="MM/YY"
              className="flex-1 px-3 py-2 border rounded dark:bg-gray-800 dark:border-gray-700 text-sm"
            />
            <input
              value={cvv}
              onChange={(e) => setCvv(e.target.value)}
              placeholder="CVV"
              inputMode="numeric"
              maxLength={4}
              className="w-24 px-3 py-2 border rounded dark:bg-gray-800 dark:border-gray-700 text-sm"
            />
          </div>

          <button
            onClick={fillTestCard}
            type="button"
            className="text-xs text-blue-600 hover:underline"
          >
            Use test card (4111 1111 1111 1111)
          </button>

          {error && <p className="text-xs text-red-600">{error}</p>}

          <button
            onClick={handlePay}
            disabled={paying}
            className="w-full bg-[#3395ff] hover:bg-[#2b82e0] disabled:opacity-60 text-white font-semibold py-2.5 rounded"
          >
            {paying ? "Processing…" : `Pay ₹${rupees}`}
          </button>

          <div className="flex items-center justify-center gap-1 text-[11px] text-gray-400 pt-1">
            <Lock className="w-3 h-3" /> Secured by Razorpay (Test Mode simulation)
          </div>
        </div>
      </div>
    </div>
  );
}
