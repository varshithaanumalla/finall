"use client";

import { useRef, useState, useEffect, useCallback } from "react";
import {
  Play,
  Pause,
  Volume2,
  VolumeX,
  Maximize,
  Minimize,
  SkipForward,
  SkipBack,
  Loader2,
  ChevronRight,
} from "lucide-react";
import { useUser } from "@/lib/AuthContext";
import axiosInstance from "@/lib/axiosinstance";

// Visible quality label per subscription plan.
const PLAN_QUALITY: Record<string, string> = {
  free: "480p",
  bronze: "720p HD",
  silver: "1080p Full HD",
  gold: "4K Ultra HD",
};

interface VideoPlayerProps {
  video: {
    _id: string;
    videotitle: string;
    filepath: string;
  };
  nextVideo?: { _id: string; videotitle: string } | null;
  onNextVideo?: () => void;
  isWatchParty?: boolean;
  onPlaySync?: (time: number) => void;
  onPauseSync?: (time: number) => void;
  onSeekSync?: (time: number) => void;
}

export default function VideoPlayer({
  video,
  nextVideo,
  onNextVideo,
  isWatchParty = false,
  onPlaySync,
  onPauseSync,
  onSeekSync,
}: VideoPlayerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [showControls, setShowControls] = useState(true);
  const [buffered, setBuffered] = useState(0);
  const controlsTimeout = useRef<NodeJS.Timeout | null>(null);

  // Subscription-aware ads & quality.
  const { user } = useUser();
  const [plan, setPlan] = useState<string>("free");
  const isFreePlan = plan === "free";
  // Pre-roll ad gate (free users only): show an ad overlay before playback.
  const [adActive, setAdActive] = useState(false);
  const [adCountdown, setAdCountdown] = useState(5);
  // Brief on-screen "+10s" / "-10s" feedback after a double-tap seek.
  const [seekFeedback, setSeekFeedback] = useState<null | "forward" | "back">(null);

  // Fetch the viewer's current plan to decide ads / quality.
  useEffect(() => {
    let cancelled = false;
    const loadPlan = async () => {
      if (!user) {
        setPlan("free");
        return;
      }
      try {
        const res = await axiosInstance.get("/subscription/current");
        if (!cancelled) setPlan(res.data.currentPlan || "free");
      } catch {
        if (!cancelled) setPlan("free");
      }
    };
    loadPlan();
    return () => {
      cancelled = true;
    };
  }, [user]);

  // Seek by +/- 10 seconds
  const seekBy = (seconds: number) => {
    const v = videoRef.current;
    if (!v) return;
    // Use the element's live duration (state `duration` can be 0/stale).
    const dur = Number.isFinite(v.duration) && v.duration > 0 ? v.duration : Infinity;
    const newTime = Math.max(0, Math.min(v.currentTime + seconds, dur));
    v.currentTime = newTime;
    setCurrentTime(newTime);
    if (onSeekSync) onSeekSync(newTime);
  };

  // Play/Pause toggle
  const togglePlay = useCallback(() => {
    if (!videoRef.current) return;
    if (isPlaying) {
      videoRef.current.pause();
      if (onPauseSync) onPauseSync(videoRef.current.currentTime);
    } else {
      // Free users see a short pre-roll ad before the FIRST playback.
      if (isFreePlan && !adShownRef.current && !isWatchParty) {
        startAd();
        return;
      }
      videoRef.current.play();
      if (onPlaySync) onPlaySync(videoRef.current.currentTime);
    }
  }, [isPlaying, onPlaySync, onPauseSync, isFreePlan, isWatchParty]);

  // Pre-roll ad (free plan only).
  const adShownRef = useRef(false);
  const startAd = () => {
    adShownRef.current = true;
    setAdActive(true);
    setAdCountdown(5);
    const timer = setInterval(() => {
      setAdCountdown((c) => {
        if (c <= 1) {
          clearInterval(timer);
          finishAd();
          return 0;
        }
        return c - 1;
      });
    }, 1000);
  };
  const finishAd = () => {
    setAdActive(false);
    videoRef.current?.play().catch(() => {});
    if (onPlaySync && videoRef.current) onPlaySync(videoRef.current.currentTime);
  };

  // Volume control
  const toggleMute = () => {
    if (!videoRef.current) return;
    videoRef.current.muted = !videoRef.current.muted;
    setIsMuted(videoRef.current.muted);
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const vol = parseFloat(e.target.value);
    if (!videoRef.current) return;
    videoRef.current.volume = vol;
    setVolume(vol);
    setIsMuted(vol === 0);
  };

  // Fullscreen toggle
  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  // Seekbar interaction
  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const time = parseFloat(e.target.value);
    if (!videoRef.current) return;
    videoRef.current.currentTime = time;
    setCurrentTime(time);
    if (onSeekSync) onSeekSync(time);
  };

  // Mobile double-tap gestures
  const lastTap = useRef<number>(0);
  const tapTimeout = useRef<NodeJS.Timeout | null>(null);
  const feedbackTimeout = useRef<NodeJS.Timeout | null>(null);

  // Show a brief +10s / -10s indicator.
  const flashSeekFeedback = (side: "left" | "right") => {
    setSeekFeedback(side === "right" ? "forward" : "back");
    if (feedbackTimeout.current) clearTimeout(feedbackTimeout.current);
    feedbackTimeout.current = setTimeout(() => setSeekFeedback(null), 600);
  };

  // Unified handler for a tap/click on the left or right half of the video.
  // Double tap/click within 300ms => seek ±10s (YouTube-style). A single
  // tap/click toggles play/pause.
  const handleZoneActivate = (side: "left" | "right") => {
    const now = Date.now();
    if (now - lastTap.current < 300) {
      // Double tap/click detected -> seek.
      if (tapTimeout.current) clearTimeout(tapTimeout.current);
      seekBy(side === "right" ? 10 : -10);
      flashSeekFeedback(side);
      lastTap.current = 0;
    } else {
      lastTap.current = now;
      tapTimeout.current = setTimeout(() => {
        togglePlay();
        lastTap.current = 0;
      }, 300);
    }
  };

  // Show/hide controls with timeout
  const showControlsTemporarily = () => {
    setShowControls(true);
    if (controlsTimeout.current) clearTimeout(controlsTimeout.current);
    controlsTimeout.current = setTimeout(() => {
      if (isPlaying) setShowControls(false);
    }, 3000);
  };

  // Format time as MM:SS
  const formatTime = (time: number) => {
    const mins = Math.floor(time / 60);
    const secs = Math.floor(time % 60);
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  // Video event listeners
  useEffect(() => {
    const v = videoRef.current;
    if (!v) return;

    const onTimeUpdate = () => setCurrentTime(v.currentTime);
    const onLoadedMetadata = () => {
      setDuration(v.duration);
      setIsLoading(false);
    };
    const onPlay = () => setIsPlaying(true);
    const onPause = () => setIsPlaying(false);
    const onWaiting = () => setIsLoading(true);
    const onPlaying = () => setIsLoading(false);
    const onProgress = () => {
      if (v.buffered.length > 0) {
        setBuffered(v.buffered.end(v.buffered.length - 1));
      }
    };

    v.addEventListener("timeupdate", onTimeUpdate);
    v.addEventListener("loadedmetadata", onLoadedMetadata);
    v.addEventListener("play", onPlay);
    v.addEventListener("pause", onPause);
    v.addEventListener("waiting", onWaiting);
    v.addEventListener("playing", onPlaying);
    v.addEventListener("progress", onProgress);

    return () => {
      v.removeEventListener("timeupdate", onTimeUpdate);
      v.removeEventListener("loadedmetadata", onLoadedMetadata);
      v.removeEventListener("play", onPlay);
      v.removeEventListener("pause", onPause);
      v.removeEventListener("waiting", onWaiting);
      v.removeEventListener("playing", onPlaying);
      v.removeEventListener("progress", onProgress);
    };
  }, [video?._id]);

  // Fullscreen change listener
  useEffect(() => {
    const onFsChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener("fullscreenchange", onFsChange);
    return () => document.removeEventListener("fullscreenchange", onFsChange);
  }, []);

  // Keyboard shortcuts
  useEffect(() => {
    const onKeydown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA")) return;
      switch (e.key) {
        case " ":
        case "k":
          e.preventDefault();
          togglePlay();
          break;
        case "ArrowRight":
          seekBy(10);
          break;
        case "ArrowLeft":
          seekBy(-10);
          break;
        case "f":
          toggleFullscreen();
          break;
        case "m":
          toggleMute();
          break;
      }
    };
    window.addEventListener("keydown", onKeydown);
    return () => window.removeEventListener("keydown", onKeydown);
  }, [togglePlay]);

  if (!video) return null;

  return (
    <div
      ref={containerRef}
      className="relative aspect-video bg-black rounded-lg overflow-hidden group"
      onMouseMove={showControlsTemporarily}
      onMouseLeave={() => isPlaying && setShowControls(false)}
    >
      <video
        ref={videoRef}
        className="w-full h-full"
        poster="/placeholder.svg?height=480&width=854"
        preload="metadata"
      >
        <source
          src={`${process.env.BACKEND_URL}/${video?.filepath}`}
          type="video/mp4"
        />
        Your browser does not support the video tag.
      </video>

      {/* Loading spinner */}
      {isLoading && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <Loader2 className="w-12 h-12 text-white animate-spin" />
        </div>
      )}

      {/* Quality badge (reflects subscription plan) */}
      <div className="absolute top-2 left-2 flex items-center gap-1">
        <span className="bg-black/70 text-white text-[10px] font-semibold px-2 py-0.5 rounded">
          {PLAN_QUALITY[plan] || "480p"}
        </span>
        {!isFreePlan && (
          <span className="bg-green-600 text-white text-[10px] font-semibold px-2 py-0.5 rounded">
            Ad-free
          </span>
        )}
      </div>

      {/* Ad banner for free users during playback */}
      {isFreePlan && isPlaying && !adActive && (
        <div className="absolute bottom-20 left-2 right-2 bg-yellow-400/95 text-black text-xs px-3 py-2 rounded flex items-center justify-between z-20">
          <span>📢 Ad • Upgrade to remove ads & unlock higher quality</span>
          <a href="/subscriptions" className="font-bold underline">
            Go Premium
          </a>
        </div>
      )}

      {/* Pre-roll ad overlay (free users, before playback) */}
      {adActive && (
        <div className="absolute inset-0 z-30 bg-black flex flex-col items-center justify-center text-white">
          <div className="absolute top-2 left-2 bg-yellow-400 text-black text-xs font-bold px-2 py-0.5 rounded">
            Ad
          </div>
          <div className="text-center px-6">
            <p className="text-lg font-semibold mb-2">Advertisement</p>
            <p className="text-sm text-gray-300 mb-4">
              You're on the Free plan. Upgrade to watch ad-free in higher quality.
            </p>
            <a
              href="/subscriptions"
              className="inline-block bg-red-600 hover:bg-red-700 px-4 py-2 rounded text-sm font-semibold"
            >
              Go Premium
            </a>
          </div>
          <button
            onClick={finishAd}
            disabled={adCountdown > 0}
            className="absolute bottom-6 right-6 bg-white/20 hover:bg-white/30 disabled:opacity-60 disabled:cursor-not-allowed px-4 py-2 rounded text-sm"
          >
            {adCountdown > 0 ? `Skip Ad in ${adCountdown}s` : "Skip Ad ▶"}
          </button>
        </div>
      )}

      {/* Mobile touch zones */}
      {/* Seek zones: double-click (desktop) or double-tap (mobile) the left
          half to rewind 10s, the right half to forward 10s. A single
          click/tap toggles play/pause. Leaves the middle-bottom free for the
          controls bar. */}
      <div
        className="absolute left-0 top-0 w-1/2 h-[80%]"
        onClick={() => handleZoneActivate("left")}
        onTouchEnd={(e) => {
          e.preventDefault();
          handleZoneActivate("left");
        }}
      />
      <div
        className="absolute right-0 top-0 w-1/2 h-[80%]"
        onClick={() => handleZoneActivate("right")}
        onTouchEnd={(e) => {
          e.preventDefault();
          handleZoneActivate("right");
        }}
      />

      {/* Seek feedback indicators */}
      {seekFeedback === "back" && (
        <div className="absolute left-[15%] top-1/2 -translate-y-1/2 bg-black/60 text-white rounded-full px-4 py-3 flex items-center gap-1 pointer-events-none">
          <SkipBack className="w-6 h-6" />
          <span className="text-sm font-semibold">10s</span>
        </div>
      )}
      {seekFeedback === "forward" && (
        <div className="absolute right-[15%] top-1/2 -translate-y-1/2 bg-black/60 text-white rounded-full px-4 py-3 flex items-center gap-1 pointer-events-none">
          <span className="text-sm font-semibold">10s</span>
          <SkipForward className="w-6 h-6" />
        </div>
      )}

      {/* Controls overlay */}
      <div
        className={`absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4 transition-opacity duration-300 ${
          showControls || !isPlaying ? "opacity-100" : "opacity-0"
        }`}
      >
        {/* Seekbar */}
        <div className="flex items-center gap-2 mb-2">
          <span className="text-white text-xs">{formatTime(currentTime)}</span>
          <input
            type="range"
            min={0}
            max={duration || 0}
            value={currentTime}
            onChange={handleSeek}
            className="flex-1 h-1 cursor-pointer appearance-none rounded-full"
            style={{
              background: `linear-gradient(to right, #ef4444 ${duration ? (currentTime / duration) * 100 : 0}%, #4b5563 ${duration ? (currentTime / duration) * 100 : 0}%)`,
            }}
          />
          <span className="text-white text-xs">{formatTime(duration)}</span>
        </div>

        {/* Control buttons */}
        <div className="flex items-center gap-4">
          {/* Seek backward 10s */}
          <button
            onClick={() => seekBy(-10)}
            className="text-white hover:text-red-400 transition-colors"
            title="Backward 10s"
          >
            <SkipBack className="w-5 h-5" />
          </button>

          {/* Play/Pause */}
          <button
            onClick={togglePlay}
            className="text-white hover:text-red-400 transition-colors"
            title={isPlaying ? "Pause" : "Play"}
          >
            {isPlaying ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6" />}
          </button>

          {/* Seek forward 10s */}
          <button
            onClick={() => seekBy(10)}
            className="text-white hover:text-red-400 transition-colors"
            title="Forward 10s"
          >
            <SkipForward className="w-5 h-5" />
          </button>

          {/* Volume */}
          <div className="flex items-center gap-2 group/vol">
            <button
              onClick={toggleMute}
              className="text-white hover:text-red-400 transition-colors"
            >
              {isMuted || volume === 0 ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
            </button>
            <input
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={isMuted ? 0 : volume}
              onChange={handleVolumeChange}
              className="w-0 group-hover/vol:w-20 transition-all h-1 cursor-pointer appearance-none rounded-full bg-gray-600"
            />
          </div>

          <div className="flex-1" />

          {/* Next video */}
          {nextVideo && onNextVideo && (
            <button
              onClick={onNextVideo}
              className="text-white hover:text-red-400 transition-colors flex items-center gap-1"
              title="Next video"
            >
              <span className="text-xs hidden sm:inline">Next</span>
              <ChevronRight className="w-5 h-5" />
            </button>
          )}

          {/* Fullscreen */}
          <button
            onClick={toggleFullscreen}
            className="text-white hover:text-red-400 transition-colors"
            title="Fullscreen"
          >
            {isFullscreen ? <Minimize className="w-5 h-5" /> : <Maximize className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Center play button when paused */}
      {!isPlaying && !isLoading && (
        <button
          onClick={togglePlay}
          className="absolute inset-0 flex items-center justify-center pointer-events-none"
        >
          <div className="bg-black/50 rounded-full p-4">
            <Play className="w-10 h-10 text-white ml-1" />
          </div>
        </button>
      )}

      {/* Watch party indicator */}
      {isWatchParty && (
        <div className="absolute top-2 right-2 bg-red-600 text-white text-xs px-2 py-1 rounded-full flex items-center gap-1">
          <span className="w-2 h-2 bg-white rounded-full animate-pulse" />
          Watch Party
        </div>
      )}
    </div>
  );
}
