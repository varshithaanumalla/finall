"use client";

import { useState, useEffect } from "react";
import { Download, Clock, CheckCircle, XCircle } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { useUser } from "@/lib/AuthContext";
import axiosInstance from "@/lib/axiosinstance";
import { Button } from "./ui/button";
import { toast } from "sonner";

export default function DownloadsContent() {
  const { user } = useUser();
  const [downloads, setDownloads] = useState<any[]>([]);
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      loadDownloads();
      loadStats();
    }
  }, [user]);

  const loadDownloads = async () => {
    if (!user) return;
    try {
      const res = await axiosInstance.get("/downloads/user-downloads");
      setDownloads(res.data.downloads);
    } catch (error) {
      console.error("Load downloads error:", error);
    } finally {
      setLoading(false);
    }
  };

  const loadStats = async () => {
    if (!user) return;
    try {
      const res = await axiosInstance.get("/downloads/stats");
      setStats(res.data);
    } catch (error) {
      console.error("Load stats error:", error);
    }
  };

  if (!user) {
    return (
      <div className="text-center py-12">
        <Download className="w-16 h-16 mx-auto text-gray-400 mb-4" />
        <h2 className="text-xl font-semibold mb-2">Your Downloads</h2>
        <p className="text-gray-600">Sign in to view and manage your downloads.</p>
      </div>
    );
  }

  if (loading) {
    return <div>Loading downloads...</div>;
  }

  return (
    <div className="max-w-4xl space-y-6">
      {/* Stats header */}
      {stats && (
        <div className="bg-gray-100 dark:bg-gray-800 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-semibold capitalize">{stats.plan} Plan</h3>
              <p className="text-sm text-gray-500">
                Daily limit: {stats.todayCount}/{stats.dailyLimit} downloads used today
              </p>
            </div>
            <div className="text-right">
              <p className="text-2xl font-bold">{stats.remaining}</p>
              <p className="text-xs text-gray-500">remaining today</p>
            </div>
          </div>
          {/* Progress bar */}
          <div className="mt-2 h-2 bg-gray-300 dark:bg-gray-700 rounded-full overflow-hidden">
            <div
              className="h-full bg-blue-600 rounded-full"
              style={{
                width: `${stats.dailyLimit > 0 ? (stats.todayCount / stats.dailyLimit) * 100 : 0}%`,
              }}
            />
          </div>
        </div>
      )}

      <h1 className="text-2xl font-bold">Downloads</h1>

      {downloads.length === 0 ? (
        <div className="text-center py-12">
          <Download className="w-16 h-16 mx-auto text-gray-400 mb-4" />
          <h2 className="text-xl font-semibold mb-2">No downloads yet</h2>
          <p className="text-gray-600">
            Videos you download will appear here for easy access.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {downloads.map((item) => (
            <div
              key={item._id}
              className="flex items-center gap-4 p-3 bg-white dark:bg-gray-900 border rounded-lg"
            >
              <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <h3 className="font-medium text-sm truncate">{item.videotitle}</h3>
                <p className="text-xs text-gray-500">
                  {item.videochanel} • Downloaded{" "}
                  {formatDistanceToNow(new Date(item.downloadDate))} ago
                </p>
              </div>
              <span className="text-xs bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded capitalize">
                {item.userPlan}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
