"use client";

import { useState, useEffect } from "react";
import { Check, Crown, Zap, Star, Award } from "lucide-react";
import { useUser } from "@/lib/AuthContext";
import axiosInstance from "@/lib/axiosinstance";
import { toast } from "sonner";
import { Button } from "./ui/button";
import FakeRazorpayCheckout from "./FakeRazorpayCheckout";

const PLAN_ICONS: Record<string, any> = {
  free: Award,
  bronze: Zap,
  silver: Star,
  gold: Crown,
};

const PLAN_COLORS: Record<string, string> = {
  free: "border-gray-300",
  bronze: "border-amber-600",
  silver: "border-gray-400",
  gold: "border-yellow-500",
};

export default function SubscriptionPlans() {
  const { user, login } = useUser();
  const [plans, setPlans] = useState<any>(null);
  const [currentPlan, setCurrentPlan] = useState<string>("free");
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState<string | null>(null);
  // Demo-mode checkout modal data.
  const [checkout, setCheckout] = useState<{
    planId: string;
    orderId: string;
    amount: number;
  } | null>(null);

  useEffect(() => {
    fetchPlans();
    if (user) fetchCurrentSubscription();
  }, [user]);

  const fetchPlans = async () => {
    try {
      const res = await axiosInstance.get("/subscription/plans");
      setPlans(res.data.plans);
    } catch (error) {
      console.error("Fetch plans error:", error);
    } finally {
      setLoading(false);
    }
  };

  const fetchCurrentSubscription = async () => {
    try {
      const res = await axiosInstance.get("/subscription/current");
      setCurrentPlan(res.data.currentPlan);
    } catch (error: any) {
      // User not found (deleted) or unauthorized -> treat as free and clear a
      // stale session so the UI doesn't get stuck.
      const status = error?.response?.status;
      if (status === 404 || status === 401) {
        setCurrentPlan("free");
        if (typeof window !== "undefined") {
          localStorage.removeItem("token");
          localStorage.removeItem("user");
        }
      } else {
        console.error("Fetch subscription error:", error);
      }
    }
  };

  const handleSubscribe = async (planId: string) => {
    if (!user) {
      toast.error("Please login to subscribe");
      return;
    }
    if (planId === "free" || planId === currentPlan) return;

    setProcessing(planId);
    try {
      // Step 1: Create order
      const orderRes = await axiosInstance.post("/subscription/create-order", {
        planId,
      });
      const { orderId, amount, currency, demoMode } = orderRes.data;

      const razorpay = (window as any).Razorpay;

      // Use the real Razorpay checkout only when real keys are configured
      // (demoMode === false) AND the Razorpay script is loaded. Otherwise run
      // the demo flow: simulate a successful payment and let the server verify
      // + activate the plan + send the invoice email.
      if (!demoMode && razorpay) {
        const options = {
          key: process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID || "",
          amount,
          currency,
          name: "YourTube Premium",
          description: `${planId} Plan Subscription`,
          order_id: orderId,
          handler: async (response: any) => {
            try {
              const verifyRes = await axiosInstance.post(
                "/subscription/verify-payment",
                {
                  razorpayOrderId: response.razorpay_order_id,
                  razorpayPaymentId: response.razorpay_payment_id,
                  razorpaySignature: response.razorpay_signature,
                  planId,
                }
              );
              if (verifyRes.data.subscription) {
                toast.success(`${planId} subscription activated!`);
                setCurrentPlan(planId);
                if (verifyRes.data.user) login(verifyRes.data.user);
              }
            } catch (error) {
              console.error("Verify error:", error);
              toast.error("Payment verification failed");
            } finally {
              setProcessing(null);
            }
          },
          prefill: { email: user.email, name: user.name },
          theme: { color: "#ef4444" },
          modal: {
            ondismiss: () => {
              setProcessing(null);
              toast.info("Payment cancelled");
            },
          },
        };
        const rzp = new razorpay(options);
        rzp.open();
      } else {
        // Demo mode: open the simulated Razorpay-style checkout. Verification
        // runs when the user completes the fake payment (see onSuccess below).
        setCheckout({ planId, orderId, amount });
      }
    } catch (error) {
      console.error("Subscribe error:", error);
      toast.error("Failed to process subscription");
      setProcessing(null);
    }
  };

  // Verify a (demo) payment with the server and activate the plan.
  const completeDemoPayment = async () => {
    if (!checkout) return;
    const { planId, orderId } = checkout;
    try {
      const verifyRes = await axiosInstance.post("/subscription/verify-payment", {
        razorpayOrderId: orderId,
        razorpayPaymentId: `pay_demo_${Date.now()}`,
        razorpaySignature: `sig_demo_${Date.now()}`,
        planId,
      });
      if (verifyRes.data.subscription) {
        toast.success(`${planId} subscription activated!`);
        setCurrentPlan(planId);
        if (verifyRes.data.user) login(verifyRes.data.user);
      }
    } catch (error) {
      console.error("Verify error:", error);
      toast.error("Payment verification failed");
    } finally {
      setCheckout(null);
      setProcessing(null);
    }
  };

  if (loading || !plans) {
    return <div>Loading plans...</div>;
  }

  return (
    <div className="max-w-5xl mx-auto p-6">
      <h1 className="text-2xl font-bold mb-2">Choose Your Plan</h1>
      <p className="text-gray-500 mb-8">
        Unlock premium features with our subscription plans
      </p>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {Object.entries(plans).map(([planId, plan]: [string, any]) => {
          const Icon = PLAN_ICONS[planId];
          const isCurrent = currentPlan === planId;
          return (
            <div
              key={planId}
              className={`relative border-2 rounded-lg p-6 ${PLAN_COLORS[planId]} ${
                isCurrent ? "ring-2 ring-blue-500" : ""
              }`}
            >
              {isCurrent && (
                <span className="absolute top-2 right-2 bg-blue-500 text-white text-xs px-2 py-0.5 rounded-full">
                  Current
                </span>
              )}
              <div className="flex items-center gap-2 mb-4">
                <Icon className="w-6 h-6" />
                <h3 className="text-lg font-semibold capitalize">{plan.name}</h3>
              </div>
              <div className="mb-4">
                <span className="text-3xl font-bold">₹{plan.price}</span>
                {plan.price > 0 && (
                  <span className="text-sm text-gray-500">/month</span>
                )}
              </div>
              <ul className="space-y-2 mb-6">
                {plan.features.map((feature: string, i: number) => (
                  <li key={i} className="flex items-start gap-2 text-sm">
                    <Check className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                    {feature}
                  </li>
                ))}
              </ul>
              <Button
                onClick={() => handleSubscribe(planId)}
                disabled={isCurrent || planId === "free" || processing === planId}
                className={`w-full ${
                  isCurrent
                    ? "bg-gray-200 text-gray-500"
                    : "bg-red-600 hover:bg-red-700 text-white"
                }`}
              >
                {processing === planId
                  ? "Processing..."
                  : isCurrent
                  ? "Current Plan"
                  : planId === "free"
                  ? "Free"
                  : `Upgrade to ${plan.name}`}
              </Button>
            </div>
          );
        })}
      </div>

      {checkout && (
        <FakeRazorpayCheckout
          amount={checkout.amount}
          planName={plans[checkout.planId]?.name || checkout.planId}
          email={user?.email}
          name={user?.name}
          onSuccess={completeDemoPayment}
          onDismiss={() => {
            setCheckout(null);
            setProcessing(null);
            toast.info("Payment cancelled");
          }}
        />
      )}
    </div>
  );
}
