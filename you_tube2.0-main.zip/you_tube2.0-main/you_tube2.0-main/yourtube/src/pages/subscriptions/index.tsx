import SubscriptionPlans from "@/components/SubscriptionPlans";
import { Suspense } from "react";

export default function SubscriptionPage() {
  return (
    <main className="flex-1 p-6">
      <Suspense fallback={<div>Loading subscription plans...</div>}>
        <SubscriptionPlans />
      </Suspense>
    </main>
  );
}
