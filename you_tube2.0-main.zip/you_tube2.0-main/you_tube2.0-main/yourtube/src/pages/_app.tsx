import Header from "@/components/Header";
import Sidebar from "@/components/Sidebar";
import { Toaster } from "@/components/ui/sonner";
import "@/styles/globals.css";
import type { AppProps } from "next/app";
import { UserProvider } from "../lib/AuthContext";
import { useEffect } from "react";
import axiosInstance from "../lib/axiosinstance";

export default function App({ Component, pageProps }: AppProps) {
  // Apply whatever theme is currently stored (Header is responsible for
  // setting it from the server on login / manual toggle). Default dark.
  useEffect(() => {
    const apply = () => {
      const theme = localStorage.getItem("theme") || "dark";
      if (theme === "dark") {
        document.documentElement.classList.add("dark");
      } else {
        document.documentElement.classList.remove("dark");
      }
    };
    apply();
    // Re-apply when the Header updates the theme.
    window.addEventListener("themechange", apply);

    // If logged in, fetch the server-resolved theme (IST time default or saved
    // preference) and apply it. This is authoritative and works on any page.
    const token = typeof window !== "undefined" ? localStorage.getItem("token") : null;
    if (token) {
      axiosInstance
        .get("/theme/current")
        .then((res) => {
          const eff = res.data?.effectiveTheme;
          if (eff === "light" || eff === "dark") {
            localStorage.setItem("theme", eff);
            apply();
          }
        })
        .catch(() => {});
    }

    return () => window.removeEventListener("themechange", apply);
  }, []);

  return (
    <UserProvider>
      <div className="min-h-screen bg-white dark:bg-gray-950 text-black dark:text-white">
        <title>Your-Tube Clone</title>
        <Header />
        <Toaster />
        <div className="flex">
          <Sidebar />
          <Component {...pageProps} />
        </div>
      </div>
    </UserProvider>
  );
}
